import AsyncStorage from "@react-native-async-storage/async-storage";

export type AgeBand = "5-7" | "8-10" | "11-13";
export type LearningGoal = "reading" | "writing" | "math" | "confidence";
export type LearnerProfile = { name: string; ageBand: AgeBand; goal: LearningGoal; onboardingComplete: boolean; onboardingSkipped: boolean };

export const defaultLearnerProfile: LearnerProfile = { name: "Maya", ageBand: "8-10", goal: "confidence", onboardingComplete: false, onboardingSkipped: false };
const KEY = "primer.learner-profile.v1";

export function shouldShowOnboardingReminder(profile: LearnerProfile) { return profile.onboardingSkipped && !profile.onboardingComplete; }

export function normalizeLearnerProfile(value: unknown): LearnerProfile {
  if (!value || typeof value !== "object") return defaultLearnerProfile;
  const candidate = value as Partial<LearnerProfile>;
  const name = typeof candidate.name === "string" && candidate.name.trim() ? candidate.name.trim().slice(0, 40) : defaultLearnerProfile.name;
  const ageBand = candidate.ageBand === "5-7" || candidate.ageBand === "8-10" || candidate.ageBand === "11-13" ? candidate.ageBand : defaultLearnerProfile.ageBand;
  const goal = candidate.goal === "reading" || candidate.goal === "writing" || candidate.goal === "math" || candidate.goal === "confidence" ? candidate.goal : defaultLearnerProfile.goal;
  const onboardingComplete = typeof candidate.onboardingComplete === "boolean" ? candidate.onboardingComplete : defaultLearnerProfile.onboardingComplete;
  const onboardingSkipped = typeof candidate.onboardingSkipped === "boolean" ? candidate.onboardingSkipped : defaultLearnerProfile.onboardingSkipped;
  return { name, ageBand, goal, onboardingComplete, onboardingSkipped };
}

export async function loadLearnerProfile(): Promise<LearnerProfile> {
  try { const raw = await AsyncStorage.getItem(KEY); return raw ? normalizeLearnerProfile(JSON.parse(raw)) : defaultLearnerProfile; } catch { return defaultLearnerProfile; }
}

export async function saveLearnerProfile(profile: LearnerProfile) {
  await AsyncStorage.setItem(KEY, JSON.stringify(normalizeLearnerProfile(profile)));
}
