import type { ActivityRecord } from "@/lib/learning-analytics";

export type ActivityDateFilter = "All time" | "7 days" | "30 days";

export function filterActivity(activity: ActivityRecord[], subject: string, dateFilter: ActivityDateFilter, now = Date.now()) {
  const maxAge = dateFilter === "All time" ? Number.POSITIVE_INFINITY : (dateFilter === "7 days" ? 7 : 30) * 24 * 60 * 60 * 1000;
  return activity.filter((item) => (subject === "All" || item.subject === subject) && now - new Date(item.completedAt).getTime() <= maxAge);
}
