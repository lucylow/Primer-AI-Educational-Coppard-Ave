export type CompletionAction = "review" | "continue" | "explore";

export function getCompletionActionLabel(action: CompletionAction) {
  if (action === "review") return "Review this lesson";
  if (action === "continue") return "Choose my next lesson";
  return "Explore more lessons";
}
