import type { Language } from "@/lib/i18n";

const labels = {
  en: { All: "All", Reading: "Reading", Writing: "Writing", Math: "Math", "All time": "All time", "7 days": "7 days", "30 days": "30 days", "Completed only": "Completed only", "All activity": "All activity", "This week": "This week", "Needs review": "Needs review", "Save current": "Save current", Start: "Start", Review: "Review", Show: "Show", lessons: "lessons" },
  es: { All: "Todas", Reading: "Lectura", Writing: "Escritura", Math: "Matemáticas", "All time": "Todo el tiempo", "7 days": "7 días", "30 days": "30 días", "Completed only": "Solo completadas", "All activity": "Toda la actividad", "This week": "Esta semana", "Needs review": "Necesita repaso", "Save current": "Guardar actual", Start: "Comenzar", Review: "Repasar", Show: "Mostrar", lessons: "lecciones" },
} as const;

type LabelKey = keyof typeof labels.en;
export function getFilterLabel(language: Language, key: LabelKey) { return labels[language]?.[key] ?? labels.en[key] ?? key; }
export function getSubjectLabel(language: Language, subject: "All" | "Reading" | "Writing" | "Math") { return getFilterLabel(language, subject); }
