import type { AgeBand } from "@/lib/learner-profile";

export type CompletionCopyKey =
  | "tutorSessionComplete"
  | "tutorSessionCompleteText"
  | "tutorYoungSessionComplete"
  | "tutorYoungSessionCompleteText"
  | "tutorQuietComplete"
  | "tutorQuietCompleteText";

export function getCompletionCopyKeys(ageBand: AgeBand, quieterFeedback: boolean): { title: CompletionCopyKey; body: CompletionCopyKey } {
  if (quieterFeedback) return { title: "tutorQuietComplete", body: "tutorQuietCompleteText" };
  if (ageBand === "5-7") return { title: "tutorYoungSessionComplete", body: "tutorYoungSessionCompleteText" };
  return { title: "tutorSessionComplete", body: "tutorSessionCompleteText" };
}
