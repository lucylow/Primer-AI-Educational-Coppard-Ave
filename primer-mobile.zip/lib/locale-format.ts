import type { Language } from "@/lib/i18n";

export function formatDuration(minutes: number, language: Language) {
  const value = Math.max(0, Math.round(minutes));
  return language === "es" ? `${value} min` : `${value} min`;
}

export function formatWeekday(value: string | number | Date, language: Language, width: "short" | "long" = "short") {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat(language === "es" ? "es-ES" : "en-US", { weekday: width }).format(date);
}

export function formatTodayHeader(value: string | number | Date, language: Language) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return language === "es" ? "HOY" : "TODAY";
  return new Intl.DateTimeFormat(language === "es" ? "es-ES" : "en-US", { weekday: "long", month: "long", day: "numeric" }).format(date).toUpperCase();
}

export function formatActivityDate(value: string | number | Date, language: Language) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return language === "es" ? "Fecha no disponible" : "Date unavailable";
  return new Intl.DateTimeFormat(language === "es" ? "es-ES" : "en-US", { month: "short", day: "numeric" }).format(date);
}
