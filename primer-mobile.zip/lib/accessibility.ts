export function lessonAccessibilityLabel(title: string, subject: string, durationMinutes: number) {
  return `Start ${title}, ${subject}, ${durationMinutes} minutes`;
}

export function activityAccessibilityLabel(dayName: string, minutes: number, lessonCount: number) {
  return `${dayName}: ${minutes} minutes across ${lessonCount} ${lessonCount === 1 ? "lesson" : "lessons"}`;
}
