import type { Lesson } from "@/data/lessons";
import type { ActivityRecord } from "@/lib/learning-analytics";
import type { AgeBand } from "@/lib/learner-profile";
import { getAgeBandLearningProfile } from "./age-band-adaptation";

export type LessonRecommendation = { lesson: Lesson; reason: string };

export function getLessonRecommendation(lessons: Lesson[], completedLessonIds: string[], recentActivity: ActivityRecord[], ageBand?: AgeBand): LessonRecommendation {
  const unfinished = lessons.filter((lesson) => !completedLessonIds.includes(lesson.id));
  const candidates = unfinished.length > 0 ? unfinished : lessons;
  const subjectCounts = recentActivity.reduce<Record<string, number>>((counts, item) => {
    counts[item.subject] = (counts[item.subject] ?? 0) + 1;
    return counts;
  }, {});
  const lesson = [...candidates].sort((a, b) => {
    const pacing = ageBand ? getAgeBandLearningProfile(ageBand) : null;
    const aScore = (subjectCounts[a.subject] ?? 0) * 10 + a.durationMinutes + (pacing ? Math.max(0, a.durationMinutes - pacing.preferredLessonMinutes) * 8 : 0);
    const bScore = (subjectCounts[b.subject] ?? 0) * 10 + b.durationMinutes + (pacing ? Math.max(0, b.durationMinutes - pacing.preferredLessonMinutes) * 8 : 0);
    return aScore - bScore;
  })[0];
  const reason = completedLessonIds.includes(lesson.id)
    ? "A familiar favorite to revisit"
    : subjectCounts[lesson.subject]
      ? `A fresh ${lesson.subject.toLowerCase()} practice to balance your week`
      : "A great next step for your learning path";
  return { lesson, reason };
}

export function recommendNextLesson(lessons: Lesson[], completedLessonIds: string[], recentActivity: ActivityRecord[], ageBand?: AgeBand): Lesson {
  return getLessonRecommendation(lessons, completedLessonIds, recentActivity, ageBand).lesson;
}
