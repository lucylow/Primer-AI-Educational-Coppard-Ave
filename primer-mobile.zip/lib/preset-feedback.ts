export type PresetFeedbackMode = "inline" | "alert";

export function getPresetFeedbackMode(quieterFeedback: boolean): PresetFeedbackMode {
  return quieterFeedback ? "inline" : "alert";
}

export function shouldShowPresetAlert(quieterFeedback: boolean): boolean {
  return getPresetFeedbackMode(quieterFeedback) === "alert";
}

export function shouldShowPresetInlineFeedback(quieterFeedback: boolean): boolean {
  return getPresetFeedbackMode(quieterFeedback) === "inline";
}
