import type { ActivityRecord } from "@/lib/learning-analytics";

export type ReviewItem = ActivityRecord & { due: boolean; reviewReason: string };

export function getReviewItems(activity: ActivityRecord[], now = new Date()): ReviewItem[] {
  return activity
    .map((item) => {
      const ageDays = Math.floor((now.getTime() - new Date(item.completedAt).getTime()) / 86400000);
      const intervalDays = item.hintsUsed > 0 ? 2 : 4;
      const due = ageDays >= intervalDays;
      return { ...item, due, reviewReason: item.hintsUsed > 0 ? "Review the idea with a little extra practice" : "Keep this skill fresh" };
    })
    .filter((item) => item.due)
    .sort((a, b) => new Date(a.completedAt).getTime() - new Date(b.completedAt).getTime());
}
