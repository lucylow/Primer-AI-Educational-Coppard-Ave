import type { ActivityRecord } from "@/lib/learning-analytics";
import type { Language } from "@/lib/i18n";

export function getWeeklyComparisonLabel(totalMinutes: number, goalMinutes = 30) {
  if (totalMinutes <= 0) return "No learning minutes logged yet";
  if (totalMinutes >= goalMinutes) return "You reached your weekly goal";
  return `${Math.max(goalMinutes - totalMinutes, 0)} minutes left to reach your goal`;
}

export function getPreviousWeekMinutes(activity: ActivityRecord[], now = Date.now()) {
  const week = 7 * 24 * 60 * 60 * 1000;
  return activity.filter((item) => { const age = now - new Date(item.completedAt).getTime(); return age > week && age <= week * 2; }).reduce((sum, item) => sum + item.durationMinutes, 0);
}

export type TrendDirection = "up" | "down" | "steady";

export function getTrendDirection(currentMinutes: number, previousMinutes: number): TrendDirection {
  if (currentMinutes === previousMinutes) return "steady";
  return currentMinutes > previousMinutes ? "up" : "down";
}

export function getLocalizedWeekOverWeekLabel(currentMinutes: number, previousMinutes: number, language: Language = "en") {
  const label = getWeekOverWeekLabel(currentMinutes, previousMinutes);
  if (language === "en") return label;
  if (label === "New momentum this week") return "Nuevo impulso esta semana";
  if (label === "No comparison yet") return "Todavía no hay comparación";
  if (label === "Same pace as last week") return "El mismo ritmo que la semana pasada";
  const more = label.match(/^(\d+) more minutes than last week$/);
  if (more) return `${more[1]} minutos más que la semana pasada`;
  const fewer = label.match(/^(\d+) fewer minutes than last week$/);
  if (fewer) return `${fewer[1]} minutos menos que la semana pasada`;
  return label;
}

export function getWeekOverWeekLabel(currentMinutes: number, previousMinutes: number) {
  if (previousMinutes === 0) return currentMinutes > 0 ? "New momentum this week" : "No comparison yet";
  const delta = currentMinutes - previousMinutes;
  if (delta === 0) return "Same pace as last week";
  return delta > 0 ? `${delta} more minutes than last week` : `${Math.abs(delta)} fewer minutes than last week`;
}
