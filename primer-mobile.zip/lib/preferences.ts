import AsyncStorage from "@react-native-async-storage/async-storage";

const REDUCED_MOTION_KEY = "primer.preferences.reduced-motion";

export async function loadReducedMotion() {
  return (await AsyncStorage.getItem(REDUCED_MOTION_KEY)) === "true";
}

export async function saveReducedMotion(enabled: boolean) {
  await AsyncStorage.setItem(REDUCED_MOTION_KEY, String(enabled));
}
