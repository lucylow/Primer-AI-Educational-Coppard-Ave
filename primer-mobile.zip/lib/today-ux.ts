import AsyncStorage from "@react-native-async-storage/async-storage";

const CUE_KEY = "primer.today-cue-dismissed.v1";

export function getDailyFocusMessage(lessonTitle: string, durationMinutes: number, completed: boolean) {
  if (completed) return `You’ve already explored ${lessonTitle}. A short review keeps the idea fresh.`;
  return `A calm ${durationMinutes}-minute step is enough for today.`;
}

export async function loadTodayCueDismissed() {
  try { return (await AsyncStorage.getItem(CUE_KEY)) === "true"; } catch { return false; }
}

export async function dismissTodayCue() {
  try { await AsyncStorage.setItem(CUE_KEY, "true"); } catch { /* offline storage is best effort */ }
}
