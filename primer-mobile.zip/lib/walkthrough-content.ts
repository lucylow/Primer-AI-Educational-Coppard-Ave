import type { AgeBand } from "@/lib/learner-profile";

export type WalkthroughStepKey =
  | "walkthroughStepOne"
  | "walkthroughStepTwo"
  | "walkthroughStepThree"
  | "walkthroughYoungStepOne"
  | "walkthroughYoungStepTwo"
  | "walkthroughYoungStepThree";

const standardSteps: WalkthroughStepKey[] = ["walkthroughStepOne", "walkthroughStepTwo", "walkthroughStepThree"];
const youngerSteps: WalkthroughStepKey[] = ["walkthroughYoungStepOne", "walkthroughYoungStepTwo", "walkthroughYoungStepThree"];

export function getWalkthroughStepKeys(ageBand: AgeBand): WalkthroughStepKey[] {
  return ageBand === "5-7" ? youngerSteps : standardSteps;
}
