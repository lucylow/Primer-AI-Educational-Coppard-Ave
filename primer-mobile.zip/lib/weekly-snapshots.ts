import type { ActivityRecord } from "@/lib/learning-analytics";

export type WeeklySnapshot = { weekKey: string; minutes: number; completedCount: number };

export function getWeekKey(date = new Date()) {
  const first = new Date(date.getFullYear(), 0, 1);
  const week = Math.ceil((((date.getTime() - first.getTime()) / 86400000) + first.getDay() + 1) / 7);
  return `${date.getFullYear()}-W${String(week).padStart(2, "0")}`;
}

export function buildWeeklySnapshot(activity: ActivityRecord[], date = new Date()): WeeklySnapshot {
  const weekKey = getWeekKey(date);
  const start = new Date(date); start.setDate(date.getDate() - 6); start.setHours(0, 0, 0, 0);
  const minutes = activity.filter((item) => new Date(item.completedAt) >= start).reduce((sum, item) => sum + item.durationMinutes, 0);
  return { weekKey, minutes, completedCount: activity.filter((item) => new Date(item.completedAt) >= start).length };
}
