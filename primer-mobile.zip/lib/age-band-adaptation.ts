import type { AgeBand } from "@/lib/learner-profile";

export type AgeBandLearningProfile = {
  maxExplanationSentences: number;
  preferredLessonMinutes: number;
  guidance: "gentle" | "balanced" | "stretch";
};

const profiles: Record<AgeBand, AgeBandLearningProfile> = {
  "5-7": { maxExplanationSentences: 1, preferredLessonMinutes: 10, guidance: "gentle" },
  "8-10": { maxExplanationSentences: 2, preferredLessonMinutes: 12, guidance: "balanced" },
  "11-13": { maxExplanationSentences: 3, preferredLessonMinutes: 15, guidance: "stretch" },
};

export function getAgeBandLearningProfile(ageBand: AgeBand): AgeBandLearningProfile {
  return profiles[ageBand];
}

export function adaptExplanationForAge(explanation: string, ageBand: AgeBand): string {
  const maxSentences = getAgeBandLearningProfile(ageBand).maxExplanationSentences;
  const sentences = explanation.match(/[^.!?]+[.!?]+|[^.!?]+$/g)?.map((sentence) => sentence.trim()).filter(Boolean) ?? [explanation];
  return sentences.slice(0, maxSentences).join(" ");
}

export function isAgeAppropriateLessonDuration(durationMinutes: number, ageBand: AgeBand): boolean {
  return durationMinutes <= getAgeBandLearningProfile(ageBand).preferredLessonMinutes;
}
