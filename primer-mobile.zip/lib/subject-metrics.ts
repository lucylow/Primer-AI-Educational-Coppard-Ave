import type { Lesson } from "@/data/lessons";

export function getSubjectCompletion(lessons: Lesson[], completedIds: string[]) {
  const subjects = [...new Set(lessons.map((lesson) => lesson.subject))];
  return subjects.map((subject) => {
    const subjectLessons = lessons.filter((lesson) => lesson.subject === subject);
    const completed = subjectLessons.filter((lesson) => completedIds.includes(lesson.id)).length;
    return { subject, completed, total: subjectLessons.length, percentage: subjectLessons.length === 0 ? 0 : Math.round((completed / subjectLessons.length) * 100) };
  });
}
