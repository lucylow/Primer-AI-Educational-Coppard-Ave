export type ActivityRecord = { id: string; title: string; subject: string; completedAt: string; durationMinutes: number; hintsUsed: number };

export type WeeklySummary = { totalMinutes: number; completedCount: number; hintsUsed: number; bySubject: Record<string, number> };

export function summarizeLearning(activity: ActivityRecord[], now = new Date()): WeeklySummary {
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - 6);
  const recent = activity.filter((item) => new Date(item.completedAt) >= weekStart);
  return recent.reduce<WeeklySummary>((summary, item) => {
    summary.totalMinutes += item.durationMinutes;
    summary.completedCount += 1;
    summary.hintsUsed += item.hintsUsed;
    summary.bySubject[item.subject] = (summary.bySubject[item.subject] ?? 0) + 1;
    return summary;
  }, { totalMinutes: 0, completedCount: 0, hintsUsed: 0, bySubject: {} });
}

export function dailyActivityMinutes(activity: ActivityRecord[], now = new Date()): number[] {
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(now);
    date.setHours(0, 0, 0, 0);
    date.setDate(now.getDate() - (6 - index));
    return date;
  });
  return days.map((day) => activity.filter((item) => {
    const completed = new Date(item.completedAt);
    return completed.getFullYear() === day.getFullYear() && completed.getMonth() === day.getMonth() && completed.getDate() === day.getDate();
  }).reduce((total, item) => total + item.durationMinutes, 0));
}

export function dailyLessonCounts(activity: ActivityRecord[], now = new Date()): number[] {
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(now);
    date.setHours(0, 0, 0, 0);
    date.setDate(now.getDate() - (6 - index));
    return date;
  });
  return days.map((day) => activity.filter((item) => {
    const completed = new Date(item.completedAt);
    return completed.getFullYear() === day.getFullYear() && completed.getMonth() === day.getMonth() && completed.getDate() === day.getDate();
  }).length);
}

export function nextQuestionIndex(currentIndex: number, questionCount: number, isCorrect: boolean): number | null {
  if (!isCorrect) return currentIndex;
  return currentIndex + 1 < questionCount ? currentIndex + 1 : null;
}
