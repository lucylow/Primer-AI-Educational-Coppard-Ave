import type { Lesson } from "@/data/lessons";

export function getFirstUnfinishedLesson(lessons: Lesson[], subject: string, completedIds: string[]) {
  return lessons.find((lesson) => lesson.subject === subject && !completedIds.includes(lesson.id)) ?? lessons.find((lesson) => lesson.subject === subject) ?? null;
}
