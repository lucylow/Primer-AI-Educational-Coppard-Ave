export type EffortProgress = { points: number; level: number; pointsIntoLevel: number; pointsToNextLevel: number; progress: number };

export function getLessonEffortPoints(durationMinutes: number, hintsUsed: number) {
  return Math.max(5, Math.round(durationMinutes / 2) + Math.min(hintsUsed, 3));
}

export function getEffortProgress(points: number): EffortProgress {
  const safePoints = Math.max(0, points);
  const level = Math.floor(safePoints / 25) + 1;
  const pointsIntoLevel = safePoints % 25;
  const pointsToNextLevel = 25 - pointsIntoLevel;
  return { points: safePoints, level, pointsIntoLevel, pointsToNextLevel, progress: pointsIntoLevel / 25 };
}
