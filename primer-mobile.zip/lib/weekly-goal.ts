export type WeeklyGoal = { targetMinutes: number; completedMinutes: number; remainingMinutes: number; progress: number };

export function getWeeklyGoal(completedMinutes: number, targetMinutes = 60): WeeklyGoal {
  const safeTarget = Math.max(1, targetMinutes);
  const safeCompleted = Math.max(0, completedMinutes);
  return { targetMinutes: safeTarget, completedMinutes: safeCompleted, remainingMinutes: Math.max(0, safeTarget - safeCompleted), progress: Math.min(1, safeCompleted / safeTarget) };
}
