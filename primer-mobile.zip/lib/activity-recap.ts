import type { ActivityRecord } from "@/lib/learning-analytics";

export type ActivityRecap = {
  lessonCount: number;
  totalMinutes: number;
  hintsUsed: number;
};

export function summarizeActivityRecap(activity: ActivityRecord[]): ActivityRecap {
  return activity.reduce<ActivityRecap>((summary, item) => ({
    lessonCount: summary.lessonCount + 1,
    totalMinutes: summary.totalMinutes + item.durationMinutes,
    hintsUsed: summary.hintsUsed + item.hintsUsed,
  }), { lessonCount: 0, totalMinutes: 0, hintsUsed: 0 });
}
