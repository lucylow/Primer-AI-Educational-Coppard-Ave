import type { Language } from "@/lib/i18n";

const copy: Record<string, { es: { title: string; detail: string; objective: string } }> = {
  "curious-fox": { es: { title: "El zorro curioso", detail: "Sentimientos y pistas", objective: "Encontrar detalles que muestran los sentimientos de un personaje" } },
  "better-sentence": { es: { title: "Construye una mejor oración", detail: "Sustantivos, verbos y detalles", objective: "Agregar detalles precisos a una oración clara" } },
  "patterns-around-us": { es: { title: "Patrones a nuestro alrededor", detail: "Descubre qué sigue", objective: "Reconocer un patrón numérico repetido" } },
  "main-idea": { es: { title: "Detectives de la idea principal", detail: "Encuentra lo más importante", objective: "Encontrar la idea principal de un texto corto" } },
};

export function getLocalizedLessonCopy(lesson: { id: string; title: string; detail: string; objective: string }, language: Language) {
  if (language === "es" && copy[lesson.id]) return copy[lesson.id].es;
  return { title: lesson.title, detail: lesson.detail, objective: lesson.objective };
}
