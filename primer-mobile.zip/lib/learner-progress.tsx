import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { summarizeLearning, type ActivityRecord, type WeeklySummary } from "@/lib/learning-analytics";
import { buildWeeklySnapshot, type WeeklySnapshot } from "@/lib/weekly-snapshots";
import { getLessonEffortPoints } from "@/lib/effort-points";

type LearnerProgressValue = { completedLessons: string[]; recentActivity: ActivityRecord[]; weeklySummary: WeeklySummary; weeklySnapshot: WeeklySnapshot; effortPoints: number; isHydrated: boolean; completeLesson: (lessonId: string, title: string, subject: string, durationMinutes: number, hintsUsed: number) => void; resetProgress: () => void };
const STORAGE_KEY = "primer.learner-progress.v2";
const LearnerProgressContext = createContext<LearnerProgressValue | null>(null);

export function LearnerProgressProvider({ children }: { children: ReactNode }) {
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [recentActivity, setRecentActivity] = useState<ActivityRecord[]>([]);
  const [effortPoints, setEffortPoints] = useState(0);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (stored) {
        try {
          const parsed = JSON.parse(stored) as { completedLessons?: string[]; recentActivity?: ActivityRecord[]; effortPoints?: number };
          setCompletedLessons(parsed.completedLessons ?? []);
          setRecentActivity(parsed.recentActivity ?? []);
          setEffortPoints(parsed.effortPoints ?? 0);
        } catch {
          setCompletedLessons([]);
          setRecentActivity([]);
        }
      }
      setIsHydrated(true);
    }).catch(() => setIsHydrated(true));
  }, []);

  useEffect(() => {
    if (isHydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ completedLessons, recentActivity, effortPoints })).catch(() => undefined);
  }, [completedLessons, recentActivity, effortPoints, isHydrated]);

  const weeklySummary = useMemo(() => summarizeLearning(recentActivity), [recentActivity]);
  const weeklySnapshot = useMemo(() => buildWeeklySnapshot(recentActivity), [recentActivity]);
  const value = useMemo(() => ({ completedLessons, recentActivity, weeklySummary, weeklySnapshot, effortPoints, isHydrated, resetProgress: () => { setCompletedLessons([]); setRecentActivity([]); setEffortPoints(0); }, completeLesson: (lessonId: string, title: string, subject: string, durationMinutes: number, hintsUsed: number) => {
    setCompletedLessons((current) => { if (current.includes(lessonId)) return current; setEffortPoints((points) => points + getLessonEffortPoints(durationMinutes, hintsUsed)); return [...current, lessonId]; });
    setRecentActivity((current) => [{ id: lessonId, title, subject, completedAt: new Date().toISOString(), durationMinutes, hintsUsed }, ...current.filter((item) => item.id !== lessonId)].slice(0, 10));
  }}), [completedLessons, recentActivity, weeklySummary, weeklySnapshot, effortPoints, isHydrated]);

  return <LearnerProgressContext.Provider value={value}>{children}</LearnerProgressContext.Provider>;
}

export function useLearnerProgress() {
  const value = useContext(LearnerProgressContext);
  if (!value) throw new Error("useLearnerProgress must be used inside LearnerProgressProvider");
  return value;
}
