import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { loadLanguage, saveLanguage, translate, type Language } from "@/lib/i18n";

type LanguageContextValue = { language: Language; setLanguage: (language: Language) => void; t: (key: Parameters<typeof translate>[1], values?: Record<string, string | number>) => string; isHydrated: boolean };
const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en");
  const [isHydrated, setHydrated] = useState(false);
  useEffect(() => { loadLanguage().then(setLanguageState).catch(() => setLanguageState("en")).finally(() => setHydrated(true)); }, []);
  const setLanguage = (next: Language) => { setLanguageState(next); saveLanguage(next); };
  const value = useMemo(() => ({ language, setLanguage, t: (key: Parameters<typeof translate>[1], values?: Record<string, string | number>) => translate(language, key, values), isHydrated }), [language, isHydrated]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const value = useContext(LanguageContext);
  if (!value) throw new Error("useLanguage must be used within LanguageProvider");
  return value;
}
