import AsyncStorage from "@react-native-async-storage/async-storage";

export type ReviewFilterPreferences = { subject: string; date: "All time" | "7 days" | "30 days"; completedOnly: boolean };
export type NamedReviewPreset = ReviewFilterPreferences & { id: string; name: string };

const KEY = "primer.review-filters.v1";
const PRESETS_KEY = "primer.review-presets.v1";
export const defaultReviewFilters: ReviewFilterPreferences = { subject: "All", date: "All time", completedOnly: false };

export async function loadReviewFilters(): Promise<ReviewFilterPreferences> {
  const value = await AsyncStorage.getItem(KEY);
  if (!value) return defaultReviewFilters;
  try { return { ...defaultReviewFilters, ...JSON.parse(value) }; } catch { return defaultReviewFilters; }
}

export async function saveReviewFilters(value: ReviewFilterPreferences) { await AsyncStorage.setItem(KEY, JSON.stringify(value)); }

export async function loadReviewPresets(): Promise<NamedReviewPreset[]> {
  const value = await AsyncStorage.getItem(PRESETS_KEY);
  if (!value) return [];
  try {
    const parsed = JSON.parse(value) as NamedReviewPreset[];
    return Array.isArray(parsed) ? parsed.filter((item) => item && typeof item.id === "string" && typeof item.name === "string") : [];
  } catch { return []; }
}

export async function saveReviewPreset(name: string, filters: ReviewFilterPreferences): Promise<NamedReviewPreset> {
  const trimmedName = name.trim();
  if (!trimmedName) throw new Error("Preset name is required");
  const current = await loadReviewPresets();
  const existing = current.find((item) => item.name.toLowerCase() === trimmedName.toLowerCase());
  const preset = { id: existing?.id ?? `${Date.now()}-${trimmedName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`, name: trimmedName, ...filters };
  await AsyncStorage.setItem(PRESETS_KEY, JSON.stringify([preset, ...current.filter((item) => item.name.toLowerCase() !== trimmedName.toLowerCase())].slice(0, 8)));
  return preset;
}

export async function deleteReviewPreset(id: string) {
  const current = await loadReviewPresets();
  await AsyncStorage.setItem(PRESETS_KEY, JSON.stringify(current.filter((item) => item.id !== id)));
}
