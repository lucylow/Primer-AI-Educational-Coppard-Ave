import type { Lesson } from "@/data/lessons";
import type { LearningGoal } from "@/lib/learner-profile";
import { getLessonRecommendation } from "./recommendations";
import type { ActivityRecord } from "@/lib/learning-analytics";
import type { AgeBand } from "@/lib/learner-profile";

const goalSubjects: Partial<Record<LearningGoal, Lesson["subject"]>> = { reading: "Reading", writing: "Writing", math: "Math" };

export function getGoalRecommendation(lessons: Lesson[], completedLessons: string[], recentActivity: ActivityRecord[], goal: LearningGoal, ageBand?: AgeBand) {
  const subject = goalSubjects[goal];
  const focusedLessons = subject ? lessons.filter((lesson) => lesson.subject === subject) : lessons;
  return getLessonRecommendation(focusedLessons.length > 0 ? focusedLessons : lessons, completedLessons, recentActivity, ageBand);
}

export function getGoalLabel(goal: LearningGoal, language: "en" | "es") {
  const labels = {
    en: { reading: "Reading", writing: "Writing", math: "Math", confidence: "confidence" },
    es: { reading: "Lectura", writing: "Escritura", math: "Matemáticas", confidence: "confianza" },
  } as const;
  return labels[language][goal];
}
