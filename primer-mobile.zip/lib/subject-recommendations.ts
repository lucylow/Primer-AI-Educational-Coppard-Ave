import type { Lesson } from "@/data/lessons";
import { getSubjectCompletion } from "./subject-metrics";

export function getSubjectRecommendation(lessons: Lesson[], completedIds: string[]) {
  const metrics = getSubjectCompletion(lessons, completedIds);
  return metrics.slice().sort((a, b) => (a.percentage - b.percentage) || (b.total - a.total))[0] ?? null;
}
