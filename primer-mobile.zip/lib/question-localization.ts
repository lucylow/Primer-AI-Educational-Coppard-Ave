import type { Language } from "@/lib/i18n";
import type { LessonQuestion } from "@/data/lessons";

type LocalizedQuestion = Omit<LessonQuestion, "correctChoice"> & { correctChoice: string };
const es: Record<string, Partial<LocalizedQuestion>> = {
  "curious-fox:0": { prompt: "¿Qué pista muestra que el zorro tiene curiosidad?", hint: "Busca la acción que muestra que el zorro está prestando mucha atención.", story: "El zorro se detuvo en la puerta del jardín. Sus orejas se levantaron al escuchar un suave ruido dentro.", choices: ["Levanta las orejas.", "Se queda dormido.", "Se va corriendo."], correctChoice: "Levanta las orejas.", explanation: "Levantar las orejas muestra que el zorro está prestando mucha atención." },
  "curious-fox:1": { prompt: "¿Qué hace el zorro antes de entrar al jardín?", hint: "Fíjate en lo que hace el zorro antes de dar un paso adelante.", story: "El zorro hizo una pausa en la puerta y escuchó con cuidado antes de dar un paso silencioso hacia adelante.", choices: ["Escucha con cuidado.", "Empieza a cantar.", "Cierra los ojos."], correctChoice: "Escucha con cuidado.", explanation: "Escuchar con cuidado es otra pista de que el zorro quiere aprender más." },
  "better-sentence:0": { prompt: "¿Qué oración da el detalle más claro?", hint: "Elige la oración que te ayuda a imaginar el pájaro y el lugar al que fue.", story: "Maya escribió: «El pájaro voló». Quería que su lector imaginara el momento.", choices: ["El pájaro brillante voló sobre el estanque.", "El pájaro hizo algo.", "Había un pájaro."], correctChoice: "El pájaro brillante voló sobre el estanque.", explanation: "Brillante, sobre el estanque y voló ayudan al lector a imaginar la acción." },
  "patterns-around-us:0": { prompt: "¿Qué número sigue: 2, 4, 6, 8...?", hint: "Observa cuánto aumenta cada número.", story: "Observa cuánto cambian los números cada vez. El patrón crece siempre por la misma cantidad.", choices: ["10", "9", "12"], correctChoice: "10", explanation: "El patrón suma 2 cada vez, así que 8 + 2 es 10." },
  "main-idea:0": { prompt: "¿Qué oración explica mejor de qué trata principalmente el texto?", hint: "Busca la idea que conecta todos los detalles.", story: "Un texto corto puede tener muchos detalles, pero una idea los conecta a todos.", choices: ["La idea principal conecta los detalles.", "Cada detalle no tiene relación.", "El título siempre es la respuesta."], correctChoice: "La idea principal conecta los detalles.", explanation: "La idea principal es la gran idea que conecta los detalles que la apoyan." },
};

export function getQuestionTranslationCoverage(questionsByLesson: Array<{ id: string; questions: LessonQuestion[] }>) {
  return questionsByLesson.flatMap((lesson) => lesson.questions.map((_, index) => `${lesson.id}:${index}`)).filter((key) => !es[key]);
}

export function getLocalizedQuestion(question: LessonQuestion, lessonId: string, index: number, language: Language): LocalizedQuestion {
  if (language !== "es") return question;
  return { ...question, ...es[`${lessonId}:${index}`] };
}
