import AsyncStorage from "@react-native-async-storage/async-storage";

const KEY = "primer.first-session-walkthrough.v1";

export function shouldShowFirstSessionWalkthrough(onboardingComplete: boolean, walkthroughComplete: boolean): boolean {
  return onboardingComplete && !walkthroughComplete;
}

export async function loadWalkthroughComplete(): Promise<boolean> {
  try { return (await AsyncStorage.getItem(KEY)) === "true"; } catch { return false; }
}

export async function resetWalkthrough(): Promise<void> {
  try { await AsyncStorage.setItem(KEY, "false"); } catch { /* offline storage is best effort */ }
}

export async function completeWalkthrough(): Promise<void> {
  try { await AsyncStorage.setItem(KEY, "true"); } catch { /* offline storage is best effort */ }
}
