from PIL import Image
from pathlib import Path

source = Path('/home/ubuntu/webdev-static-assets/primer-icon.png')
project = Path('/home/ubuntu/primer-mobile/assets/images')
image = Image.open(source).convert('RGBA')
image.thumbnail((512, 512), Image.Resampling.LANCZOS)
for name in ['icon.png', 'splash-icon.png', 'favicon.png', 'android-icon-foreground.png']:
    image.save(project / name, format='PNG', optimize=True, compress_level=9)
