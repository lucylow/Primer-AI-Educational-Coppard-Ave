/** @type {const} */
const themeColors = {
  primary: { light: '#246BFD', dark: '#6F98FF' },
  background: { light: '#FFF9F0', dark: '#171A1F' },
  surface: { light: '#FFFFFF', dark: '#22262D' },
  foreground: { light: '#1F2933', dark: '#F4F6F8' },
  muted: { light: '#8B8175', dark: '#B8B0A7' },
  border: { light: '#F0E8DC', dark: '#3B424B' },
  success: { light: '#2E9D65', dark: '#63C98D' },
  warning: { light: '#F4C95D', dark: '#F7D981' },
  error: { light: '#E45D52', dark: '#FF9086' },
};

module.exports = { themeColors };
