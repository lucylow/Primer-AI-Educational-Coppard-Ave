export type Subject = "Reading" | "Writing" | "Math";
export type LessonIcon = "book.fill" | "square.and.pencil" | "function";

export type LessonQuestion = {
  prompt: string;
  hint: string;
  story: string;
  choices: string[];
  correctChoice: string;
  explanation: string;
};

export type Lesson = {
  id: string;
  subject: Subject;
  title: string;
  detail: string;
  durationMinutes: number;
  level: string;
  objective: string;
  color: string;
  icon: LessonIcon;
  questions: LessonQuestion[];
};

export const lessons: Lesson[] = [
  { id: "curious-fox", subject: "Reading", title: "The curious fox", detail: "Feelings and clues", durationMinutes: 10, level: "Level 2", objective: "Finding details that show a character’s feelings", color: "#F97360", icon: "book.fill", questions: [{ prompt: "What clue shows that the fox is curious?", hint: "Look for the action that shows the fox is paying close attention.", story: "The fox stopped at the garden gate. His ears perked up as he listened to a soft rustling sound inside.", choices: ["His ears perk up.", "He falls asleep.", "He runs away."], correctChoice: "His ears perk up.", explanation: "Perking up his ears shows the fox is paying close attention." }, { prompt: "What does the fox do before entering the garden?", hint: "Notice what the fox does before taking a step forward.", story: "The fox paused at the gate and listened carefully before taking one quiet step forward.", choices: ["He listens carefully.", "He starts singing.", "He closes his eyes."], correctChoice: "He listens carefully.", explanation: "Listening carefully is another clue that the fox wants to learn more." }] },
  { id: "better-sentence", subject: "Writing", title: "Build a better sentence", detail: "Nouns, verbs, and detail", durationMinutes: 12, level: "Level 2", objective: "Adding precise details to a clear sentence", color: "#8B5CF6", icon: "square.and.pencil", questions: [{ prompt: "Which sentence gives the clearest detail?", hint: "Choose the sentence that helps you picture both the bird and where it went.", story: "Maya wrote: ‘The bird flew.’ She wanted her reader to picture the moment.", choices: ["The bright bird flew over the pond.", "The bird did a thing.", "There was a bird."], correctChoice: "The bright bird flew over the pond.", explanation: "Bright, over the pond, and flew help the reader picture the action." }] },
  { id: "patterns-around-us", subject: "Math", title: "Patterns around us", detail: "Spot what comes next", durationMinutes: 8, level: "Level 2", objective: "Recognizing a repeating number pattern", color: "#0EA5A4", icon: "function", questions: [{ prompt: "What number comes next: 2, 4, 6, 8...?", hint: "Check how much each number increases.", story: "Look at how much the numbers change each time. The pattern grows by the same amount.", choices: ["10", "9", "12"], correctChoice: "10", explanation: "The pattern adds 2 each time, so 8 + 2 is 10." }] },
  { id: "main-idea", subject: "Reading", title: "Main idea detectives", detail: "Find what matters most", durationMinutes: 15, level: "Level 2", objective: "Finding the main idea in a short passage", color: "#F97360", icon: "book.fill", questions: [{ prompt: "Which sentence best tells what the passage is mostly about?", hint: "Look for the idea that connects all the details.", story: "A short passage can have many details, but one idea connects them together.", choices: ["The main idea connects the details.", "Every detail is unrelated.", "The title is always the answer."], correctChoice: "The main idea connects the details.", explanation: "The main idea is the big idea that connects the supporting details." }] },
];

export const featuredLesson = lessons[0];
export function getLessonById(id: string) { return lessons.find((lesson) => lesson.id === id) ?? featuredLesson; }
