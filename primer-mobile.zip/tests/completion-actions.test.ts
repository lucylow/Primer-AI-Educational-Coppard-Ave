import { describe, expect, it } from "vitest";
import { getCompletionActionLabel } from "../lib/completion-actions";

describe("completion actions", () => {
  it("keeps the primary action moving the learner forward", () => {
    expect(getCompletionActionLabel("continue")).toBe("Choose my next lesson");
  });
  it("offers clear alternatives for review and exploration", () => {
    expect(getCompletionActionLabel("review")).toBe("Review this lesson");
    expect(getCompletionActionLabel("explore")).toBe("Explore more lessons");
  });
});
