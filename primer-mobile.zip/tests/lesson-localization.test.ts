import { describe, expect, it } from "vitest";
import { getLocalizedLessonCopy } from "../lib/lesson-localization";

describe("lesson localization", () => {
  const lesson = { id: "curious-fox", title: "The curious fox", detail: "Feelings and clues", objective: "Finding details" };
  it("returns Spanish metadata for supported lesson content", () => {
    expect(getLocalizedLessonCopy(lesson, "es")).toEqual({ title: "El zorro curioso", detail: "Sentimientos y pistas", objective: "Encontrar detalles que muestran los sentimientos de un personaje" });
  });
  it("falls back to source metadata in English", () => {
    expect(getLocalizedLessonCopy(lesson, "en")).toEqual({ title: lesson.title, detail: lesson.detail, objective: lesson.objective });
  });
});
