import { describe, expect, it } from "vitest";
import { getLocalizedWeekOverWeekLabel, getTrendDirection, getWeeklyComparisonLabel } from "../lib/weekly-comparison";

describe("weekly comparison", () => {
  it("classifies trend direction", () => {
    expect(getTrendDirection(12, 8)).toBe("up");
    expect(getTrendDirection(8, 12)).toBe("down");
    expect(getTrendDirection(8, 8)).toBe("steady");
  });
  it("describes remaining goal minutes", () => {
    expect(getWeeklyComparisonLabel(12, 30)).toBe("18 minutes left to reach your goal");
  });
  it("localizes week-over-week comparison labels", () => {
    expect(getLocalizedWeekOverWeekLabel(12, 0, "en")).toBe("New momentum this week");
    expect(getLocalizedWeekOverWeekLabel(12, 0, "es")).toBe("Nuevo impulso esta semana");
    expect(getLocalizedWeekOverWeekLabel(18, 12, "es")).toBe("6 minutos más que la semana pasada");
    expect(getLocalizedWeekOverWeekLabel(8, 12, "es")).toBe("4 minutos menos que la semana pasada");
  });
  it("recognizes a completed goal", () => {
    expect(getWeeklyComparisonLabel(30, 30)).toBe("You reached your weekly goal");
  });
});
