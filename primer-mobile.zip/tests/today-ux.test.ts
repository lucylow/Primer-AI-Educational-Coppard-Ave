import { beforeEach, describe, expect, it, vi } from "vitest";

const store = new Map<string, string>();
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: (key: string) => Promise.resolve(store.get(key) ?? null),
    setItem: (key: string, value: string) => { store.set(key, value); return Promise.resolve(); },
  },
}));

import { dismissTodayCue, getDailyFocusMessage, loadTodayCueDismissed } from "../lib/today-ux";

describe("Today UX", () => {
  beforeEach(() => store.clear());
  it("uses calm action-oriented copy", () => {
    expect(getDailyFocusMessage("Patterns around us", 8, false)).toContain("8-minute");
    expect(getDailyFocusMessage("Patterns around us", 8, true)).toContain("already explored");
  });
  it("persists cue dismissal locally", async () => {
    expect(await loadTodayCueDismissed()).toBe(false);
    await dismissTodayCue();
    expect(await loadTodayCueDismissed()).toBe(true);
  });
});
