import { describe, expect, it } from "vitest";
import { dailyActivityMinutes, type ActivityRecord } from "../lib/learning-analytics";

describe("daily activity", () => {
  it("returns seven day buckets in chronological order", () => {
    const now = new Date("2026-08-18T12:00:00.000Z");
    const activity: ActivityRecord[] = [
      { id: "a", title: "Fox", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 0 },
      { id: "b", title: "Math", subject: "Math", completedAt: "2026-08-15T10:00:00.000Z", durationMinutes: 8, hintsUsed: 1 },
    ];
    expect(dailyActivityMinutes(activity, now)).toEqual([0, 0, 0, 8, 0, 0, 10]);
  });

  it("returns empty zero buckets when no activity exists", () => {
    expect(dailyActivityMinutes([], new Date("2026-08-18T12:00:00.000Z"))).toEqual([0, 0, 0, 0, 0, 0, 0]);
  });
});
