import { describe, expect, it } from "vitest";
import { formatTodayHeader } from "../lib/locale-format";

describe("Today header date", () => {
  it("formats the current date in English and Spanish", () => {
    const date = new Date("2026-08-18T12:00:00.000Z");
    expect(formatTodayHeader(date, "en")).toBe("TUESDAY, AUGUST 18");
    expect(formatTodayHeader(date, "es")).toBe("MARTES, 18 DE AGOSTO");
  });
  it("uses a safe fallback for invalid dates", () => {
    expect(formatTodayHeader("invalid", "es")).toBe("HOY");
  });
});
