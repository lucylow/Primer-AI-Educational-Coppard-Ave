import { describe, expect, it } from "vitest";
import { getWeeklyGoal } from "../lib/weekly-goal";

describe("weekly goals", () => {
  it("calculates remaining minutes and progress", () => {
    expect(getWeeklyGoal(30, 60)).toEqual({ targetMinutes: 60, completedMinutes: 30, remainingMinutes: 30, progress: 0.5 });
  });

  it("clamps completed progress and protects against invalid targets", () => {
    expect(getWeeklyGoal(90, 60).progress).toBe(1);
    expect(getWeeklyGoal(-4, 0)).toEqual({ targetMinutes: 1, completedMinutes: 0, remainingMinutes: 1, progress: 0 });
  });
});
