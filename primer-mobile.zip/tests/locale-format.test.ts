import { describe, expect, it } from "vitest";
import { formatActivityDate, formatDuration } from "../lib/locale-format";

describe("locale formatting", () => {
  it("formats durations consistently in supported languages", () => {
    expect(formatDuration(8, "en")).toBe("8 min");
    expect(formatDuration(8, "es")).toBe("8 min");
    expect(formatDuration(-2, "es")).toBe("0 min");
  });
  it("formats activity dates by locale and handles invalid values", () => {
    const date = "2026-08-18T12:00:00.000Z";
    expect(formatActivityDate(date, "en")).toMatch(/Aug 18/);
    expect(formatActivityDate(date, "es")).toMatch(/18 ago/);
    expect(formatActivityDate("not-a-date", "es")).toBe("Fecha no disponible");
  });
});
