import { describe, expect, it } from "vitest";
import { formatActivityDate, formatWeekday } from "../lib/locale-format";

describe("locale weekday formatting", () => {
  it("formats the same date in English and Spanish", () => {
    const date = new Date("2026-08-18T12:00:00.000Z");
    expect(formatWeekday(date, "en", "long")).toBe("Tuesday");
    expect(formatWeekday(date, "es", "long")).toBe("martes");
    expect(formatActivityDate(date, "es")).toMatch(/18 ago/);
  });
  it("returns an empty weekday for invalid dates", () => {
    expect(formatWeekday("invalid", "en")).toBe("");
  });
});
