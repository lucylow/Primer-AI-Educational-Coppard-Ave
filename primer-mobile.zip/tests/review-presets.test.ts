import { beforeEach, describe, expect, it, vi } from "vitest";

const store = new Map<string, string>();
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: (key: string) => Promise.resolve(store.get(key) ?? null),
    setItem: (key: string, value: string) => { store.set(key, value); return Promise.resolve(); },
  },
}));

import { defaultReviewFilters, deleteReviewPreset, loadReviewPresets, saveReviewPreset } from "../lib/review-filters";
import { getPresetFeedbackMode, shouldShowPresetAlert, shouldShowPresetInlineFeedback } from "../lib/preset-feedback";

describe("named review presets", () => {
  beforeEach(() => store.clear());
  it("requires a non-empty name", async () => {
    await expect(saveReviewPreset("   ", defaultReviewFilters)).rejects.toThrow("Preset name is required");
  });
  it("uses inline feedback when quieter feedback is enabled", () => {
    expect(getPresetFeedbackMode(true)).toBe("inline");
    expect(shouldShowPresetInlineFeedback(true)).toBe(true);
    expect(shouldShowPresetAlert(true)).toBe(false);
  });
  it("uses an alert when quieter feedback is disabled", () => {
    expect(getPresetFeedbackMode(false)).toBe("alert");
    expect(shouldShowPresetInlineFeedback(false)).toBe(false);
    expect(shouldShowPresetAlert(false)).toBe(true);
  });
  it("replaces duplicate names and supports deletion", async () => {
    const first = await saveReviewPreset("Reading refresh", { ...defaultReviewFilters, subject: "Reading" });
    await saveReviewPreset("reading refresh", { ...defaultReviewFilters, subject: "Math" });
    expect((await loadReviewPresets())).toHaveLength(1);
    expect((await loadReviewPresets())[0].subject).toBe("Math");
    await deleteReviewPreset(first.id);
    expect(await loadReviewPresets()).toEqual([]);
  });
});
