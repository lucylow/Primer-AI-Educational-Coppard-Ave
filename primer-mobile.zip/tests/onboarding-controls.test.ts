import { describe, expect, it } from "vitest";
import { defaultLearnerProfile, normalizeLearnerProfile } from "../lib/learner-profile";

describe("onboarding controls", () => {
  it("keeps skipped onboarding distinct from completed onboarding", () => {
    expect(normalizeLearnerProfile({ ...defaultLearnerProfile, onboardingSkipped: true })).toMatchObject({ onboardingComplete: false, onboardingSkipped: true });
    expect(normalizeLearnerProfile({ ...defaultLearnerProfile, onboardingComplete: true, onboardingSkipped: false })).toMatchObject({ onboardingComplete: true, onboardingSkipped: false });
  });
  it("allows a completed profile to be reopened by clearing completion and skip flags", () => {
    const reopened = normalizeLearnerProfile({ ...defaultLearnerProfile, onboardingComplete: false, onboardingSkipped: false });
    expect(reopened.onboardingComplete).toBe(false);
    expect(reopened.onboardingSkipped).toBe(false);
  });
});
