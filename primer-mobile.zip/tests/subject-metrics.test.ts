import { describe, expect, it } from "vitest";
import { getSubjectCompletion } from "../lib/subject-metrics";
import type { Lesson } from "../data/lessons";

describe("subject completion metrics", () => {
  it("calculates completed and remaining lesson percentages by subject", () => {
    const catalog = [
      { id: "r1", subject: "Reading" },
      { id: "r2", subject: "Reading" },
      { id: "m1", subject: "Math" },
    ] as Lesson[];
    expect(getSubjectCompletion(catalog, ["r1", "m1"])).toEqual([
      { subject: "Reading", completed: 1, total: 2, percentage: 50 },
      { subject: "Math", completed: 1, total: 1, percentage: 100 },
    ]);
  });
});
