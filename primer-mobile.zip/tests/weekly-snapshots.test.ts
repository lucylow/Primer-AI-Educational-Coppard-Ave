import { describe, expect, it } from "vitest";
import { buildWeeklySnapshot, getWeekKey } from "../lib/weekly-snapshots";

describe("weekly snapshots", () => {
  it("creates a stable week key", () => {
    expect(getWeekKey(new Date("2026-08-19T12:00:00.000Z"))).toBe("2026-W34");
  });
  it("counts activity in the current seven-day window", () => {
    const snapshot = buildWeeklySnapshot([{ id: "a", title: "A", subject: "Reading", completedAt: "2026-08-18T12:00:00.000Z", durationMinutes: 9, hintsUsed: 0 }], new Date("2026-08-19T12:00:00.000Z"));
    expect(snapshot.minutes).toBe(9);
    expect(snapshot.completedCount).toBe(1);
  });
});
