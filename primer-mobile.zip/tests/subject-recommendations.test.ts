import { describe, expect, it } from "vitest";
import { getSubjectRecommendation } from "../lib/subject-recommendations";
import type { Lesson } from "../data/lessons";

describe("subject recommendations", () => {
  it("selects the subject with the lowest completion percentage", () => {
    const catalog = [
      { id: "r1", subject: "Reading" },
      { id: "r2", subject: "Reading" },
      { id: "m1", subject: "Math" },
    ] as Lesson[];
    expect(getSubjectRecommendation(catalog, ["r1"])?.subject).toBe("Math");
  });
});
