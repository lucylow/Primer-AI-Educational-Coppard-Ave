import { describe, expect, it } from "vitest";
import { getFirstUnfinishedLesson } from "../lib/lesson-selection";
import type { Lesson } from "../data/lessons";

describe("lesson selection", () => {
  it("returns the first unfinished lesson for a subject", () => {
    const catalog = [{ id: "r1", subject: "Reading" }, { id: "r2", subject: "Reading" }] as Lesson[];
    expect(getFirstUnfinishedLesson(catalog, "Reading", ["r1"])?.id).toBe("r2");
  });
});
