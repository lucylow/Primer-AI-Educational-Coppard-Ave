import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";

describe("Profile personalization copy", () => {
  it("interpolates age band and goal in English and Spanish", () => {
    expect(translate("en", "learnerSubtitle", { ageBand: "8-10", goal: "Math" })).toBe("8-10 learner · focused on Math");
    expect(translate("es", "learnerSubtitle", { ageBand: "8-10", goal: "Matemáticas" })).toBe("Aprendiz de 8-10 · enfocado en Matemáticas");
  });
  it("formats effort details in the selected language", () => {
    expect(translate("en", "effortPointsDetail", { points: 12, remaining: 13 })).toContain("12 effort points");
    expect(translate("es", "effortPointsDetail", { points: 12, remaining: 13 })).toContain("12 puntos de esfuerzo");
  });
});
