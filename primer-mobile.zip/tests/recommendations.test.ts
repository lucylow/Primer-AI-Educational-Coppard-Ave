import { describe, expect, it } from "vitest";
import { lessons } from "../data/lessons";
import { getLessonRecommendation, recommendNextLesson } from "../lib/recommendations";

describe("lesson recommendations", () => {
  it("prefers an unfinished lesson before repeating completed content", () => {
    const next = recommendNextLesson(lessons, [lessons[0].id], []);
    expect(next.id).not.toBe(lessons[0].id);
  });

  it("chooses the least represented subject when activity exists", () => {
    const next = recommendNextLesson(lessons, [], [
      { id: "a", title: "A", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 0 },
      { id: "b", title: "B", subject: "Reading", completedAt: "2026-08-17T10:00:00.000Z", durationMinutes: 10, hintsUsed: 0 },
    ]);
    expect(next.subject).not.toBe("Reading");
    expect(getLessonRecommendation(lessons, [], []).reason).toBe("A great next step for your learning path");
  });
});
