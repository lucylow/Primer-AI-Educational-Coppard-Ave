import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";

describe("Today greeting localization", () => {
  it("interpolates learner names in both languages", () => {
    expect(translate("en", "greeting", { name: "Maya" })).toBe("Hi, Maya.");
    expect(translate("es", "greeting", { name: "Maya" })).toBe("Hola, Maya.");
  });
  it("provides localized current-day accessibility copy", () => {
    expect(translate("en", "todayHeaderA11y", { date: "WEDNESDAY, AUGUST 19" })).toContain("Today is");
    expect(translate("es", "todayHeaderA11y", { date: "MIÉRCOLES, 19 DE AGOSTO" })).toContain("Hoy es");
  });
});
