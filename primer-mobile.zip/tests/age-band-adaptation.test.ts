import { describe, expect, it } from "vitest";
import { adaptExplanationForAge, getAgeBandLearningProfile, isAgeAppropriateLessonDuration } from "../lib/age-band-adaptation";

describe("age-band adaptation", () => {
  it("shortens explanations for younger learners while preserving full copy for older learners", () => {
    const explanation = "The pattern adds 2 each time. That means the next number is 10. Keep checking the same change.";
    expect(adaptExplanationForAge(explanation, "5-7")).toBe("The pattern adds 2 each time.");
    expect(adaptExplanationForAge(explanation, "8-10")).toBe("The pattern adds 2 each time. That means the next number is 10.");
    expect(adaptExplanationForAge(explanation, "11-13")).toBe(explanation);
  });

  it("uses shorter preferred sessions for younger learners", () => {
    expect(getAgeBandLearningProfile("5-7").preferredLessonMinutes).toBe(10);
    expect(isAgeAppropriateLessonDuration(10, "5-7")).toBe(true);
    expect(isAgeAppropriateLessonDuration(12, "5-7")).toBe(false);
    expect(isAgeAppropriateLessonDuration(15, "11-13")).toBe(true);
  });
});
