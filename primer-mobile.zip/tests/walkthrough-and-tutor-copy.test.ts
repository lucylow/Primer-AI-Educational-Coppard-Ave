import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";
import { shouldShowFirstSessionWalkthrough } from "../lib/first-session-walkthrough";
import { getWalkthroughStepKeys } from "../lib/walkthrough-content";
import { getCompletionCopyKeys } from "../lib/completion-feedback";

describe("first-session walkthrough", () => {
  it("appears after onboarding completion until it is completed", () => {
    expect(shouldShowFirstSessionWalkthrough(true, false)).toBe(true);
    expect(shouldShowFirstSessionWalkthrough(true, true)).toBe(false);
    expect(shouldShowFirstSessionWalkthrough(false, false)).toBe(false);
  });

  it("allows replay after a completed walkthrough is reset", () => {
    expect(shouldShowFirstSessionWalkthrough(true, true)).toBe(false);
    expect(shouldShowFirstSessionWalkthrough(true, false)).toBe(true);
    expect(translate("es", "replayWalkthrough")).toBe("Repetir el recorrido breve");
  });

  it("uses younger examples for ages 5–7 and standard steps otherwise", () => {
    expect(getWalkthroughStepKeys("5-7")).toEqual(["walkthroughYoungStepOne", "walkthroughYoungStepTwo", "walkthroughYoungStepThree"]);
    expect(getWalkthroughStepKeys("8-10")).toEqual(["walkthroughStepOne", "walkthroughStepTwo", "walkthroughStepThree"]);
    expect(getWalkthroughStepKeys("11-13")).toEqual(["walkthroughStepOne", "walkthroughStepTwo", "walkthroughStepThree"]);
  });

  it("localizes younger walkthrough examples in both supported languages", () => {
    expect(translate("en", "walkthroughYoungStepOne")).toBe("Pick one picture, word, or number to explore.");
    expect(translate("es", "walkthroughYoungStepTwo")).toBe("Toca una pista cuando quieras una ayuda.");
  });

  it("selects age-band and quieter completion copy", () => {
    expect(getCompletionCopyKeys("5-7", false)).toEqual({ title: "tutorYoungSessionComplete", body: "tutorYoungSessionCompleteText" });
    expect(getCompletionCopyKeys("8-10", false)).toEqual({ title: "tutorSessionComplete", body: "tutorSessionCompleteText" });
    expect(getCompletionCopyKeys("11-13", true)).toEqual({ title: "tutorQuietComplete", body: "tutorQuietCompleteText" });
  });

  it("localizes completion variants in both supported languages", () => {
    expect(translate("en", "tutorYoungSessionComplete")).toBe("You did it, explorer!");
    expect(translate("es", "tutorYoungSessionCompleteText")).toBe("Usaste tus pistas y terminaste esta lección. Elige el próximo pasito que te parezca bien.");
    expect(translate("en", "tutorQuietCompleteText")).toBe("You finished this lesson. Take a calm moment, then choose your next step.");
    expect(translate("es", "tutorQuietComplete")).toBe("Lección completada");
  });

  it("localizes walkthrough progress and replay confirmation copy", () => {
    expect(translate("en", "walkthroughProgressA11y", { current: 2, total: 3 })).toBe("Guided walkthrough step 2 of 3");
    expect(translate("es", "walkthroughProgressA11y", { current: 2, total: 3 })).toBe("Paso 2 de 3 del recorrido guiado");
    expect(translate("es", "walkthroughReplayConfirmed")).toBe("El recorrido breve está listo en Hoy.");
  });

  it("provides tutor completion copy in both supported languages", () => {
    expect(translate("en", "tutorSessionComplete")).toBe("You kept going");
    expect(translate("es", "tutorSessionComplete")).toBe("Seguiste adelante");
    expect(translate("es", "tutorLookClosely")).toBe("Miremos atentamente la historia.");
    expect(translate("es", "tutorSkillReward", { subject: "math" })).toBe("+1 habilidad de math");
  });
});
