import { beforeEach, describe, expect, it, vi } from "vitest";

const store = new Map<string, string>();
vi.mock("@react-native-async-storage/async-storage", () => ({ default: { getItem: (key: string) => Promise.resolve(store.get(key) ?? null), setItem: (key: string, value: string) => { store.set(key, value); return Promise.resolve(); } } }));

import { loadLanguage, saveLanguage, translate } from "../lib/i18n";

describe("i18n foundation", () => {
  beforeEach(() => store.clear());
  it("translates supported keys and interpolates values", () => {
    expect(translate("es", "yourNextStep")).toBe("Tu próximo paso");
    expect(translate("es", "levelLearner", { level: 2 })).toBe("Aprendiz de nivel 2");
    expect(translate("es", "choosePath")).toBe("Elige un camino y sigue tu curiosidad.");
    expect(translate("es", "finishLesson")).toBe("Terminar lección");
  });
  it("falls back to English and persists the selected language", async () => {
    expect(translate("en", "keepExploring")).toBe("Keep exploring");
    expect(await loadLanguage()).toBe("en");
    await saveLanguage("es");
    expect(await loadLanguage()).toBe("es");
  });
});
