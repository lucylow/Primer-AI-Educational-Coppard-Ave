import { describe, expect, it } from "vitest";
import { getReviewItems } from "../lib/spaced-review";

describe("spaced review", () => {
  it("prioritizes older lessons that used hints", () => {
    const items = getReviewItems([
      { id: "older", title: "Older", subject: "Reading", completedAt: "2026-08-15T12:00:00.000Z", durationMinutes: 10, hintsUsed: 1 },
      { id: "recent", title: "Recent", subject: "Math", completedAt: "2026-08-18T12:00:00.000Z", durationMinutes: 8, hintsUsed: 0 },
    ], new Date("2026-08-19T12:00:00.000Z"));
    expect(items.map((item) => item.id)).toEqual(["older"]);
    expect(items[0].reviewReason).toContain("extra practice");
  });
});
