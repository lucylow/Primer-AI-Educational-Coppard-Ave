import { describe, expect, it } from "vitest";
import { lessons } from "../data/lessons";
import { getLocalizedQuestion } from "../lib/question-localization";

describe("question localization", () => {
  it("translates question content while preserving the correct choice", () => {
    const question = getLocalizedQuestion(lessons[0].questions[0], "curious-fox", 0, "es");
    expect(question.prompt).toBe("¿Qué pista muestra que el zorro tiene curiosidad?");
    expect(question.choices).toContain(question.correctChoice);
    expect(question.correctChoice).toBe("Levanta las orejas.");
  });
  it("returns the source question in English", () => {
    expect(getLocalizedQuestion(lessons[2].questions[0], "patterns-around-us", 0, "en")).toEqual(lessons[2].questions[0]);
  });
});
