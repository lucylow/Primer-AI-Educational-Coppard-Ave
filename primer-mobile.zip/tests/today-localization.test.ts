import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";

describe("Today localization", () => {
  it("provides Spanish streak and cue copy", () => {
    expect(translate("es", "streakTitle")).toBe("Racha de aprendizaje de 5 días");
    expect(translate("es", "howPrimerWorks")).toBe("Cómo funciona The Primer");
    expect(translate("es", "exploreSubject", { subject: "Lectura", detail: "Historias" })).toBe("Explorar Lectura: Historias");
  });
  it("keeps English fallback copy available", () => {
    expect(translate("en", "continue")).toBe("Continue");
    expect(translate("en", "tutorQuote")).toContain("Mistakes are clues");
  });
});
