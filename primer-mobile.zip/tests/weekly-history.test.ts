import { describe, expect, it } from "vitest";
import { getPreviousWeekMinutes, getWeekOverWeekLabel } from "../lib/weekly-comparison";

describe("weekly history", () => {
  it("aggregates the previous seven-day window", () => {
    const now = new Date("2026-08-19T12:00:00.000Z").getTime();
    expect(getPreviousWeekMinutes([{ id: "old", title: "Old", subject: "Math", completedAt: "2026-08-10T12:00:00.000Z", durationMinutes: 12, hintsUsed: 0 }], now)).toBe(12);
  });
  it("describes week-over-week change", () => {
    expect(getWeekOverWeekLabel(20, 12)).toBe("8 more minutes than last week");
  });
});
