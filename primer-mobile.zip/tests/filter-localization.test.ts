import { describe, expect, it } from "vitest";
import { getFilterLabel, getSubjectLabel } from "../lib/filter-localization";

describe("filter localization", () => {
  it("localizes subjects and review filters", () => {
    expect(getSubjectLabel("es", "Reading")).toBe("Lectura");
    expect(getFilterLabel("es", "Completed only")).toBe("Solo completadas");
    expect(getFilterLabel("es", "7 days")).toBe("7 días");
    expect(getFilterLabel("en", "Needs review")).toBe("Needs review");
  });
});
