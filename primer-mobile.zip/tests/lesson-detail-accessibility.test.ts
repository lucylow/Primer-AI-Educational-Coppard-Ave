import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";

describe("lesson detail accessibility copy", () => {
  it("localizes completion recap labels and summaries", () => {
    expect(translate("en", "completionTime")).toBe("Time");
    expect(translate("es", "completionHints")).toBe("Pistas usadas");
    expect(translate("en", "completionRecapA11y", { time: "8 minutes", hints: 2 })).toBe("Completion recap: 8 minutes. 2 hints used.");
    expect(translate("es", "completionRecapA11y", { time: "8 minutos", hints: 2 })).toBe("Resumen de finalización: 8 minutos. 2 pistas usadas.");
  });

  it("localizes tutor-session answer-choice and progress labels", () => {
    expect(translate("en", "answerChoiceA11y", { choice: "The blue kite" })).toBe("Answer choice: The blue kite");
    expect(translate("es", "answerChoiceA11y", { choice: "La cometa azul" })).toBe("Opción de respuesta: La cometa azul");
    expect(translate("en", "tutorQuestionProgress", { current: 2, total: 3 })).toBe("Question 2 of 3");
    expect(translate("es", "tutorQuestionProgress", { current: 2, total: 3 })).toBe("Pregunta 2 de 3");
  });

  it("localizes navigation and lesson metadata labels", () => {
    expect(translate("en", "back")).toBe("Back");
    expect(translate("es", "back")).toBe("Volver");
    expect(translate("es", "youllPractice")).toBe("PRACTICARÁS");
    expect(translate("es", "withTutor")).toBe("Con tu tutor");
  });

  it("interpolates the lesson description in both supported languages", () => {
    expect(translate("en", "lessonDescription", { detail: "feelings and clues" })).toBe("Today you’ll practice feelings and clues in a short tutor-led activity.");
    expect(translate("es", "lessonDescription", { detail: "pistas y sentimientos" })).toBe("Hoy practicarás pistas y sentimientos en una actividad breve con tu tutor.");
  });

  it("interpolates objective and metadata accessibility summaries", () => {
    expect(translate("en", "lessonObjectiveA11y", { objective: "pattern clues" })).toBe("You’ll practice: pattern clues");
    expect(translate("es", "lessonObjectiveA11y", { objective: "pistas de patrones" })).toBe("Practicarás: pistas de patrones");
    expect(translate("en", "lessonMetadataA11y", { duration: 8, minutes: "minutes", skill: "Story clues", mode: "With your tutor" })).toBe("Duration: 8 minutes. Skill: Story clues. Mode: With your tutor.");
  });

  it("localizes Learn-card accessibility summaries for start and review", () => {
    expect(translate("en", "lessonCardA11y", { action: "Start", title: "Patterns around us", subject: "Math", duration: "8 minutes" })).toBe("Start Patterns around us. Subject: Math. Duration: 8 minutes.");
    expect(translate("es", "lessonCardA11y", { action: "Repasar", title: "Patrones a nuestro alrededor", subject: "Matemáticas", duration: "8 minutos" })).toBe("Repasar Patrones a nuestro alrededor. Materia: Matemáticas. Duración: 8 minutos.");
  });

  it("localizes the Learn empty state", () => {
    expect(translate("en", "moreLessonsComing")).toBe("More lessons are on the way");
    expect(translate("en", "tryAnotherSubject")).toBe("Try another subject while your tutor prepares the next activity.");
    expect(translate("es", "moreLessonsComing")).toBe("Pronto habrá más lecciones");
    expect(translate("es", "tryAnotherSubject")).toBe("Prueba otra materia mientras tu tutor prepara la próxima actividad.");
  });

  it("localizes the Learn empty-state recovery action", () => {
    expect(translate("en", "viewAllSubjects")).toBe("View all subjects");
    expect(translate("es", "viewAllSubjects")).toBe("Ver todas las materias");
  });

  it("localizes the Progress activity-history empty state", () => {
    expect(translate("en", "activityHistoryEmpty")).toBe("No activity matches these filters yet.");
    expect(translate("es", "activityHistoryEmpty")).toBe("Todavía no hay actividad que coincida con estos filtros.");
  });

  it("localizes the Progress clear-filters recovery action", () => {
    expect(translate("en", "clearFilters")).toBe("Clear filters");
    expect(translate("es", "clearFilters")).toBe("Borrar filtros");
  });

  it("localizes the active Progress filter summary", () => {
    expect(translate("en", "activityFiltersA11y", { subject: "Reading", date: "7 days", completion: "All activity" })).toBe("Activity history filters: Reading, 7 days, All activity.");
    expect(translate("es", "activityFiltersA11y", { subject: "Lectura", date: "7 días", completion: "Solo completadas" })).toBe("Filtros del historial: Lectura, 7 días, Solo completadas.");
  });

  it("localizes the Progress subtitle and insights", () => {
    expect(translate("en", "progressSubtitle")).toBe("Small steps, visible growth.");
    expect(translate("es", "progressSubtitle")).toBe("Los pasos pequeños muestran tu progreso.");
    expect(translate("en", "momentumInsightText", { hints: 3 })).toBe("Keep your streak going with one more short practice session. You’ve used 3 hints this week.");
    expect(translate("es", "momentumInsightText", { hints: 3 })).toBe("Mantén tu racha con otra sesión breve. Has usado 3 pistas esta semana.");
    expect(translate("en", "nextStepInsightText")).toBe("Try one more reading lesson this week to strengthen story clues.");
    expect(translate("es", "nextStepInsightText")).toBe("Prueba otra lección de lectura esta semana para fortalecer las pistas de historias.");
  });

  it("localizes the visual active-filter summary", () => {
    expect(translate("en", "activeFiltersLabel", { subject: "Reading", date: "7 days", completion: "All activity" })).toBe("Reading · 7 days · All activity");
    expect(translate("es", "activeFiltersLabel", { subject: "Lectura", date: "7 días", completion: "Solo completadas" })).toBe("Lectura · 7 días · Solo completadas");
  });

  it("localizes the weekly-goal status chip summary", () => {
    expect(translate("en", "weeklyGoalChipA11y", { status: "Goal complete" })).toBe("Weekly goal status: Goal complete");
    expect(translate("es", "weeklyGoalChipA11y", { status: "Meta completada" })).toBe("Estado de la meta semanal: Meta completada");
  });

  it("localizes weekly-goal labels and summaries", () => {
    expect(translate("en", "weeklyGoalLabel")).toBe("WEEKLY GOAL");
    expect(translate("es", "weeklyGoalLabel")).toBe("META SEMANAL");
    expect(translate("en", "weeklyGoalA11y", { status: "20 more minutes to go", percent: 50 })).toBe("Weekly goal: 20 more minutes to go. 50% complete.");
    expect(translate("es", "weeklyGoalA11y", { status: "Faltan 20 minutos", percent: 50 })).toBe("Meta semanal: Faltan 20 minutos. 50% completada.");
  });

  it("keeps the lesson start action localized", () => {
    expect(translate("en", "startLesson")).toBe("Start lesson");
    expect(translate("es", "startLesson")).toBe("Comenzar lección");
  });
});
