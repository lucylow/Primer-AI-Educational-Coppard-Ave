import { describe, expect, it } from "vitest";
import { lessons } from "../data/lessons";
import { translate } from "../lib/i18n";
import { getQuestionTranslationCoverage } from "../lib/question-localization";

describe("localization quality", () => {
  it("provides Spanish completion and progress copy", () => {
    expect(translate("es", "lessonCompleteLabel")).toBe("LECCIÓN COMPLETADA");
    expect(translate("es", "moreMinutes", { count: 4 })).toBe("Faltan 4 minutos");
    expect(translate("es", "lessonsCompleted", { count: 2 })).toBe("2 completadas");
  });
  it("has Spanish question content for every current lesson question", () => {
    expect(getQuestionTranslationCoverage(lessons)).toEqual([]);
  });
});
