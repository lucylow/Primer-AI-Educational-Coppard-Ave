import { describe, expect, it } from "vitest";
import { lessons } from "../data/lessons";
import { getGoalLabel, getGoalRecommendation } from "../lib/goal-recommendations";

describe("goal recommendations", () => {
  it("focuses a subject goal without losing fallback behavior", () => {
    const recommendation = getGoalRecommendation(lessons, [], [], "math");
    expect(recommendation.lesson.subject).toBe("Math");
    expect(getGoalRecommendation(lessons, [], [], "confidence").lesson).toBeTruthy();
  });
  it("localizes goal labels", () => {
    expect(getGoalLabel("reading", "en")).toBe("Reading");
    expect(getGoalLabel("reading", "es")).toBe("Lectura");
    expect(getGoalLabel("confidence", "es")).toBe("confianza");
  });
});
