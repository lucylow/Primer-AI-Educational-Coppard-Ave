import { describe, expect, it } from "vitest";
import { featuredLesson, getLessonById, lessons } from "../data/lessons";

describe("lesson catalog", () => {
  it("returns the requested lesson and falls back to the featured lesson", () => {
    expect(getLessonById("better-sentence").title).toBe("Build a better sentence");
    expect(getLessonById("unknown-id").id).toBe(featuredLesson.id);
  });

  it("keeps every question answerable with a valid correct choice", () => {
    for (const lesson of lessons) {
      expect(lesson.questions.length).toBeGreaterThan(0);
      for (const question of lesson.questions) {
        expect(question.choices).toContain(question.correctChoice);
        expect(question.hint.length).toBeGreaterThan(0);
        expect(question.explanation.length).toBeGreaterThan(0);
      }
    }
  });
});
