import { describe, expect, it } from "vitest";
import { defaultLearnerProfile, normalizeLearnerProfile } from "../lib/learner-profile";

describe("first-run onboarding state", () => {
  it("starts incomplete by default", () => {
    expect(defaultLearnerProfile.onboardingComplete).toBe(false);
  });
  it("preserves an explicit completed state while keeping profile fields normalized", () => {
    expect(normalizeLearnerProfile({ name: " Sam ", ageBand: "5-7", goal: "reading", onboardingComplete: true })).toEqual({ name: "Sam", ageBand: "5-7", goal: "reading", onboardingComplete: true, onboardingSkipped: false });
  });
  it("falls back to incomplete for malformed completion state", () => {
    expect(normalizeLearnerProfile({ onboardingComplete: "yes" }).onboardingComplete).toBe(false);
  });
});
