import { describe, expect, it } from "vitest";
import { getEffortProgress, getLessonEffortPoints } from "../lib/effort-points";

describe("effort points", () => {
  it("rewards lesson completion and a small amount of persistence", () => {
    expect(getLessonEffortPoints(10, 0)).toBe(5);
    expect(getLessonEffortPoints(12, 2)).toBe(8);
  });
  it("converts points into a simple learner level", () => {
    expect(getEffortProgress(0)).toMatchObject({ level: 1, pointsToNextLevel: 25, progress: 0 });
    expect(getEffortProgress(27)).toMatchObject({ level: 2, pointsIntoLevel: 2, pointsToNextLevel: 23 });
  });
});
