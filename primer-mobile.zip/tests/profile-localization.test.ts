import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";

describe("Profile localization", () => {
  it("translates settings and safety copy in Spanish", () => {
    expect(translate("es", "tutorEncouragement")).toBe("Ánimo del tutor");
    expect(translate("es", "reduceMotion")).toBe("Reducir movimiento");
    expect(translate("es", "grownUpCorner")).toBe("Zona para adultos");
  });
  it("keeps reset confirmation copy clear in both languages", () => {
    expect(translate("en", "resetProgressTitle")).toContain("Reset");
    expect(translate("es", "resetProgressText")).toContain("borrará");
  });
});
