import { describe, expect, it } from "vitest";
import { translate } from "../lib/i18n";

describe("shared language contract", () => {
  it("keeps the tab labels aligned with the selected language", () => {
    expect(translate("en", "today")).toBe("Today");
    expect(translate("es", "today")).toBe("Hoy");
    expect(translate("es", "profile")).toBe("Perfil");
  });
});
