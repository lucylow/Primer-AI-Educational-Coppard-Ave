import { describe, expect, it } from "vitest";
import type { ActivityRecord } from "../lib/learning-analytics";

describe("activity detail aggregation", () => {
  it("summarizes subjects and hints for a selected day", () => {
    const activity: ActivityRecord[] = [
      { id: "a", title: "Fox", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 1 },
      { id: "b", title: "Patterns", subject: "Math", completedAt: "2026-08-18T11:00:00.000Z", durationMinutes: 8, hintsUsed: 2 },
    ];
    expect(activity.map((item) => item.subject)).toEqual(["Reading", "Math"]);
    expect(activity.reduce((total, item) => total + item.hintsUsed, 0)).toBe(3);
  });
});
