import { describe, expect, it } from "vitest";
import { activityAccessibilityLabel } from "../lib/accessibility";
import { dailyLessonCounts, type ActivityRecord } from "../lib/learning-analytics";

describe("selected day details", () => {
  it("counts lessons in the matching day bucket", () => {
    const now = new Date("2026-08-18T12:00:00.000Z");
    const activity: ActivityRecord[] = [
      { id: "a", title: "Fox", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 0 },
      { id: "b", title: "Math", subject: "Math", completedAt: "2026-08-18T11:00:00.000Z", durationMinutes: 8, hintsUsed: 0 },
    ];
    expect(dailyLessonCounts(activity, now).at(-1)).toBe(2);
  });

  it("uses singular and plural accessibility wording correctly", () => {
    expect(activityAccessibilityLabel("Tuesday", 10, 1)).toBe("Tuesday: 10 minutes across 1 lesson");
    expect(activityAccessibilityLabel("Tuesday", 18, 2)).toBe("Tuesday: 18 minutes across 2 lessons");
  });
});
