import { describe, expect, it } from "vitest";
import { filterActivity } from "../lib/activity-filters";
import type { ActivityRecord } from "../lib/learning-analytics";

describe("activity filters", () => {
  const now = new Date("2026-08-19T12:00:00.000Z").getTime();
  const activity: ActivityRecord[] = [
    { id: "recent-reading", title: "Fox", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 0 },
    { id: "old-math", title: "Patterns", subject: "Math", completedAt: "2026-07-01T10:00:00.000Z", durationMinutes: 8, hintsUsed: 1 },
  ];

  it("filters by subject", () => {
    expect(filterActivity(activity, "Reading", "All time", now).map((item) => item.id)).toEqual(["recent-reading"]);
  });

  it("filters old activity from the seven-day range", () => {
    expect(filterActivity(activity, "All", "7 days", now).map((item) => item.id)).toEqual(["recent-reading"]);
  });
});
