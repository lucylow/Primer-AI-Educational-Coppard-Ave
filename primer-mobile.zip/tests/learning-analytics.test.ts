import { describe, expect, it } from "vitest";
import { nextQuestionIndex, summarizeLearning, type ActivityRecord } from "../lib/learning-analytics";
import { summarizeActivityRecap } from "../lib/activity-recap";
import { translate } from "../lib/i18n";

describe("learning analytics", () => {
  it("aggregates recent minutes, completions, hints, and subjects", () => {
    const now = new Date("2026-08-18T12:00:00.000Z");
    const activity: ActivityRecord[] = [
      { id: "a", title: "Fox", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 1 },
      { id: "b", title: "Math", subject: "Math", completedAt: "2026-08-15T10:00:00.000Z", durationMinutes: 8, hintsUsed: 0 },
      { id: "old", title: "Old", subject: "Writing", completedAt: "2026-08-01T10:00:00.000Z", durationMinutes: 12, hintsUsed: 2 },
    ];
    expect(summarizeLearning(activity, now)).toEqual({ totalMinutes: 18, completedCount: 2, hintsUsed: 1, bySubject: { Reading: 1, Math: 1 } });
  });

  it("aggregates persisted activity for the Progress recap", () => {
    const activity: ActivityRecord[] = [
      { id: "a", title: "Fox", subject: "Reading", completedAt: "2026-08-18T10:00:00.000Z", durationMinutes: 10, hintsUsed: 1 },
      { id: "b", title: "Math", subject: "Math", completedAt: "2026-08-15T10:00:00.000Z", durationMinutes: 8, hintsUsed: 0 },
    ];
    expect(summarizeActivityRecap(activity)).toEqual({ lessonCount: 2, totalMinutes: 18, hintsUsed: 1 });
  });

  it("localizes the Progress activity recap summary", () => {
    expect(translate("en", "activityRecapA11y", { lessons: 2, time: "18 minutes", hints: 1, trend: "5 more minutes than last week" })).toBe("Recent learning: 2 lessons, 18 minutes, 1 hints used. Trend: 5 more minutes than last week.");
    expect(translate("es", "activityRecapA11y", { lessons: 2, time: "18 minutos", hints: 1, trend: "5 minutos más que la semana pasada" })).toBe("Aprendizaje reciente: 2 lecciones, 18 minutos, 1 pistas usadas. Ritmo: 5 minutos más que la semana pasada.");
  });

  it("localizes the activity-history recap action", () => {
    expect(translate("en", "openActivityHistory")).toBe("Open activity history");
    expect(translate("es", "openActivityHistory")).toBe("Abrir historial de actividad");
  });

  it("keeps the learner on an incorrect question and advances only when correct", () => {
    expect(nextQuestionIndex(0, 2, false)).toBe(0);
    expect(nextQuestionIndex(0, 2, true)).toBe(1);
    expect(nextQuestionIndex(1, 2, true)).toBeNull();
  });
});
