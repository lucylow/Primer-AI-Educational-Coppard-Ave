import { describe, expect, it } from "vitest";
import { defaultLearnerProfile, normalizeLearnerProfile, shouldShowOnboardingReminder } from "../lib/learner-profile";

describe("learner profile", () => {
  it("normalizes valid profile fields and trims the name", () => {
    expect(normalizeLearnerProfile({ name: "  Alex  ", ageBand: "11-13", goal: "math" })).toEqual({ name: "Alex", ageBand: "11-13", goal: "math", onboardingComplete: false, onboardingSkipped: false });
  });
  it("falls back safely for malformed profile data", () => {
    expect(normalizeLearnerProfile({ name: "", ageBand: "adult", goal: "unknown" })).toEqual(defaultLearnerProfile);
    expect(normalizeLearnerProfile(null)).toEqual(defaultLearnerProfile);
  });
  it("shows a reminder only for a skipped, incomplete profile", () => {
    expect(shouldShowOnboardingReminder({ ...defaultLearnerProfile, onboardingSkipped: true })).toBe(true);
    expect(shouldShowOnboardingReminder({ ...defaultLearnerProfile, onboardingSkipped: true, onboardingComplete: true })).toBe(false);
    expect(shouldShowOnboardingReminder(defaultLearnerProfile)).toBe(false);
  });
});
