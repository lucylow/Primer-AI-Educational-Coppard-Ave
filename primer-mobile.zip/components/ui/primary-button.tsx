import { Pressable, StyleSheet, Text } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";

type PrimaryButtonProps = {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  testID?: string;
  icon?: "arrow.forward" | "checkmark.circle.fill";
};

export function PrimaryButton({ label, onPress, disabled = false, testID, icon = "arrow.forward" }: PrimaryButtonProps) {
  return <Pressable testID={testID} accessibilityRole="button" accessibilityState={{ disabled }} accessibilityLabel={label} disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, disabled && styles.disabled, pressed && !disabled && styles.pressed]}><Text style={styles.label}>{label}</Text><IconSymbol name={icon} size={20} color="#FFFFFF" /></Pressable>;
}

const styles = StyleSheet.create({ button: { minHeight: 56, borderRadius: 19, backgroundColor: "#246BFD", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingHorizontal: 20 }, disabled: { backgroundColor: "#B8C8EC" }, pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] }, label: { color: "#FFFFFF", fontSize: 15, fontWeight: "900" } });
