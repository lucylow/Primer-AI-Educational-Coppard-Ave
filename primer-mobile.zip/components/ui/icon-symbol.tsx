// Cross-platform icon wrapper: SF Symbols on iOS and Material Icons on Android/web.
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "arrow.forward": "arrow-forward",
  "local.fire-department": "local-fire-department",
  "menu.book": "menu-book",
  "square.and.pencil": "edit",
  "function": "calculate",
  "clock": "schedule",
  "arrow.up.right": "trending-up",
  "arrow.down.right": "trending-down",
  "minus": "remove",
  "chart.bar.fill": "bar-chart",
  "person.crop.circle": "account-circle",
  "lightbulb.fill": "lightbulb",
  "star.fill": "star",
  "checkmark.circle.fill": "check-circle",
  "play.fill": "play-arrow",
  "book.fill": "menu-book",
} as IconMapping;

export function IconSymbol({ name, size = 24, color, style }: { name: IconSymbolName; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: SymbolWeight }) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
