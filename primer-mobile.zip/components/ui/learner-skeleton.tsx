import { StyleSheet, View } from "react-native";

export function LearnerSkeleton({ label = "Loading your learning" }: { label?: string }) {
  return <View style={styles.container} accessibilityRole="progressbar" accessibilityLabel={label} accessibilityState={{ busy: true }}><View style={styles.avatar} /><View style={styles.lineShort} /><View style={styles.lineLong} /><View style={styles.card} /><View style={styles.card} /></View>;
}

const styles = StyleSheet.create({ container: { flex: 1, padding: 20, gap: 14, backgroundColor: "#FFFDF9" }, avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: "#E8F0FF", alignSelf: "flex-end" }, lineShort: { height: 20, width: "38%", borderRadius: 8, backgroundColor: "#F3EEE7", marginTop: 8 }, lineLong: { height: 14, width: "62%", borderRadius: 7, backgroundColor: "#F3EEE7" }, card: { height: 120, borderRadius: 22, backgroundColor: "#F3EEE7", marginTop: 12 } });
