import { StyleSheet, View } from "react-native";

type ProgressBarProps = { value: number; color?: string; testID?: string };

export function ProgressBar({ value, color = "#246BFD", testID }: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(1, value));
  return <View testID={testID} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 1, now: clamped }} style={styles.track}><View style={[styles.fill, { width: `${clamped * 100}%`, backgroundColor: color }]} /></View>;
}

const styles = StyleSheet.create({ track: { height: 8, borderRadius: 8, backgroundColor: "#E7E0D8", overflow: "hidden" }, fill: { height: "100%", borderRadius: 8 } });
