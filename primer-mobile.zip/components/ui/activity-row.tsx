import { Pressable, StyleSheet, Text, View } from "react-native";
import type { Language } from "@/lib/i18n";
import { getFilterLabel } from "@/lib/filter-localization";
import { formatDuration } from "@/lib/locale-format";

export function ActivityRow({ title, subject, durationMinutes, hintsUsed, language = "en", onReview }: { title: string; subject: string; durationMinutes: number; hintsUsed: number; language?: Language; onReview?: () => void }) {
  return <View style={styles.row}><View style={styles.copy}><Text style={styles.title}>{title}</Text><Text style={styles.meta}>{subject} · {formatDuration(durationMinutes, language)} · {hintsUsed} {language === "es" ? "pistas" : hintsUsed === 1 ? "hint" : "hints"}</Text></View>{onReview && <Pressable onPress={onReview} accessibilityRole="button" accessibilityLabel={`${getFilterLabel(language, "Review")} ${title}`} style={({ pressed }) => [styles.button, pressed && styles.pressed]}><Text style={styles.buttonText}>{getFilterLabel(language, "Review")}</Text></Pressable>}</View>;
}

const styles = StyleSheet.create({ row: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 5 }, copy: { flex: 1 }, title: { color: "#1F2933", fontWeight: "700", fontSize: 13 }, meta: { color: "#8B8175", fontSize: 12, marginTop: 3 }, button: { backgroundColor: "#E8F0FF", borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7 }, buttonText: { color: "#246BFD", fontWeight: "800", fontSize: 11 }, pressed: { opacity: 0.72 } });
