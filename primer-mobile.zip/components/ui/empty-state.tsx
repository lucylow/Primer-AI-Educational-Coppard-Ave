import { Pressable, StyleSheet, Text, View } from "react-native";

export function EmptyState({ title, message, actionLabel, onAction }: { title: string; message: string; actionLabel?: string; onAction?: () => void }) {
  return <View style={styles.container} accessibilityRole="text"><Text style={styles.title}>{title}</Text><Text style={styles.message}>{message}</Text>{actionLabel && onAction && <Pressable onPress={onAction} accessibilityRole="button" accessibilityLabel={actionLabel} style={({ pressed }) => [styles.action, pressed && styles.pressed]}><Text style={styles.actionText}>{actionLabel}</Text></Pressable>}</View>;
}

const styles = StyleSheet.create({ container: { padding: 24, borderRadius: 18, backgroundColor: "#F3EEE7", marginTop: 8 }, title: { color: "#1F2933", fontWeight: "800", fontSize: 16 }, message: { color: "#6F665C", lineHeight: 19, marginTop: 6 }, action: { alignSelf: "flex-start", marginTop: 14, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 12, backgroundColor: "#E8F0FF" }, actionText: { color: "#246BFD", fontWeight: "800", fontSize: 13 }, pressed: { opacity: 0.72 } });
