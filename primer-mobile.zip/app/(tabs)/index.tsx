import { useRouter } from "expo-router";
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useEffect, useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useLearnerProgress } from "@/lib/learner-progress";
import { lessons } from "@/data/lessons";
import { getGoalLabel, getGoalRecommendation } from "@/lib/goal-recommendations";
import { LearnerSkeleton } from "@/components/ui/learner-skeleton";
import { dismissTodayCue, getDailyFocusMessage, loadTodayCueDismissed } from "@/lib/today-ux";
import { completeWalkthrough, loadWalkthroughComplete } from "@/lib/first-session-walkthrough";
import { getEffortProgress } from "@/lib/effort-points";
import { useLanguage } from "@/lib/language-provider";
import { formatTodayHeader } from "@/lib/locale-format";
import { defaultLearnerProfile, loadLearnerProfile, saveLearnerProfile, shouldShowOnboardingReminder, type AgeBand, type LearningGoal, type LearnerProfile } from "@/lib/learner-profile";
import { getWalkthroughStepKeys } from "@/lib/walkthrough-content";

const subjects = [
  { title: "Reading", detail: "Stories & meaning", progress: "3 of 5 this week", color: "#F97360", icon: "menu-book" as const },
  { title: "Writing", detail: "Ideas into words", progress: "2 of 4 this week", color: "#8B5CF6", icon: "edit" as const },
  { title: "Math", detail: "Patterns & puzzles", progress: "4 of 6 this week", color: "#0EA5A4", icon: "calculate" as const },
];

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const { language, t } = useLanguage();
  const { completedLessons, recentActivity, effortPoints, isHydrated } = useLearnerProgress();
  const [cueDismissed, setCueDismissed] = useState(true);
  const [learnerProfile, setLearnerProfile] = useState<LearnerProfile>(defaultLearnerProfile);
  const [onboardingVisible, setOnboardingVisible] = useState(false);
  const [walkthroughVisible, setWalkthroughVisible] = useState(false);
  const [walkthroughStep, setWalkthroughStep] = useState(0);
  useEffect(() => { loadTodayCueDismissed().then(setCueDismissed).catch(() => setCueDismissed(false)); Promise.all([loadLearnerProfile(), loadWalkthroughComplete()]).then(([profile, walkthroughComplete]) => { setLearnerProfile(profile); setOnboardingVisible(!profile.onboardingComplete && !profile.onboardingSkipped); if (profile.onboardingComplete && !walkthroughComplete) setWalkthroughVisible(true); }).catch(() => setLearnerProfile(defaultLearnerProfile)); }, []);
  const recommendation = getGoalRecommendation(lessons, completedLessons, recentActivity, learnerProfile.goal, learnerProfile.ageBand);
  const recommendedLesson = recommendation.lesson;
  if (!isHydrated) return <LearnerSkeleton label={t("loadingProgress")} />;
  const lessonComplete = completedLessons.includes(recommendedLesson.id);
  const effortProgress = getEffortProgress(effortPoints);
  const walkthroughSteps = getWalkthroughStepKeys(learnerProfile.ageBand).map((key) => t(key));

  return (
    <ScreenContainer className="px-5 pt-4" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View>
            <Text className="text-sm font-semibold text-muted" accessibilityLabel={t("todayHeaderA11y", { date: formatTodayHeader(new Date(), language) })}>{formatTodayHeader(new Date(), language)}</Text>
            <Text className="mt-1 text-3xl font-bold text-foreground">{t("greeting", { name: learnerProfile.name })}</Text>
          </View>
          <Pressable onPress={() => router.push("/profile")} style={({ pressed }) => [styles.avatar, pressed && styles.pressed]} accessibilityLabel={t("openProfile")}>
            <Text style={styles.avatarText}>{learnerProfile.name.slice(0, 1).toUpperCase()}</Text>
          </Pressable>
        </View>

        {!cueDismissed && <View style={styles.cueCard} accessibilityRole="summary"><View style={styles.cueIcon}><IconSymbol name="lightbulb.fill" size={20} color="#8B6B00" /></View><View style={styles.cueCopy}><Text style={styles.cueTitle}>{t("howPrimerWorks")}</Text><Text style={styles.cueText}>{t("primerCueText")}</Text></View><Pressable onPress={() => { setCueDismissed(true); dismissTodayCue(); }} accessibilityRole="button" accessibilityLabel={t("dismissCue")} style={styles.cueClose}><Text style={styles.cueCloseText}>×</Text></Pressable></View>}

        {shouldShowOnboardingReminder(learnerProfile) && <Pressable onPress={() => router.push("/profile")} accessibilityRole="button" accessibilityLabel={t("finishProfileSetup")} style={({ pressed }) => [styles.setupReminder, pressed && styles.cardPressed]}><View style={styles.setupReminderIcon}><IconSymbol name="person.fill" size={18} color="#246BFD" /></View><View style={styles.setupReminderCopy}><Text style={styles.setupReminderTitle}>{t("finishProfileSetup")}</Text><Text style={styles.setupReminderText}>{t("finishProfileSetupText")}</Text></View><Text style={styles.setupReminderArrow}>›</Text></Pressable>}

        <View style={styles.rewardCard} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 25, now: effortProgress.pointsIntoLevel }} accessibilityLabel={`${effortProgress.points} effort points, level ${effortProgress.level}`}><View style={styles.rewardIcon}><IconSymbol name="star.fill" size={20} color="#8B6B00" /></View><View style={styles.rewardCopy}><Text style={styles.rewardTitle}>{t("levelLearner", { level: effortProgress.level })}</Text><Text style={styles.rewardSubtitle}>{t("pointsUntilNext", { points: effortProgress.pointsToNextLevel })}</Text></View><Text style={styles.rewardPoints}>{effortProgress.points} pts</Text></View>

        <View style={styles.streakCard} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 7, now: 5 }} accessibilityLabel={t("streakA11y")}>
          <View style={styles.streakIcon}><IconSymbol name="local-fire-department" size={24} color="#1F2933" /></View>
          <View style={styles.streakCopy}>
            <Text style={styles.streakTitle}>{t("streakTitle")}</Text>
            <Text style={styles.streakSubtitle}>{t("streakSubtitle")}</Text>
          </View>
          <Text style={styles.streakCount}>5</Text>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text className="text-xl font-bold text-foreground">{t("yourNextStep")}</Text>
            <Text className="mt-1 text-sm text-muted">{getDailyFocusMessage(recommendedLesson.title, recommendedLesson.durationMinutes, lessonComplete)}</Text>
          </View>
          <View style={styles.progressPill}><Text style={styles.progressPillText}>1 / 3</Text></View>
        </View>

        <Pressable onPress={() => router.push({ pathname: "/lesson", params: { lessonId: recommendedLesson.id } })} style={({ pressed }) => [styles.heroCard, pressed && styles.cardPressed]} accessibilityRole="button" accessibilityLabel={`Open recommended lesson ${recommendedLesson.title}`} testID="today-recommended-lesson">
          <View style={styles.heroTop}><Text style={styles.heroEyebrow}>{lessonComplete ? `${recommendedLesson.subject.toUpperCase()} · ${t("completedBadge")}` : `${recommendedLesson.subject.toUpperCase()} · ${recommendedLesson.level.toUpperCase()}`}</Text><IconSymbol name="arrow-forward" size={22} color="#FFFFFF" /></View>
          <Text style={styles.heroTitle}>{recommendedLesson.title}</Text>
          <Text style={styles.heroBody}>{recommendedLesson.objective}</Text><Text style={styles.recommendationReason}>{recommendation.reason}</Text>
          <View style={styles.heroFooter}><View style={styles.duration}><IconSymbol name="schedule" size={16} color="#FFFFFF" /><Text style={styles.durationText}>{recommendedLesson.durationMinutes} min</Text></View><Text style={styles.startText}>{lessonComplete ? t("reviewLesson", { title: "" }).trim() : t("continue")}</Text></View>
        </Pressable>

        <View style={styles.sectionHeader}><Text className="text-xl font-bold text-foreground">{t("keepExploring")}</Text><Pressable onPress={() => router.push("/learn")}><Text style={{ color: colors.primary, fontWeight: "700" }}>{t("seeAll")}</Text></Pressable></View>
        <View style={styles.subjectGrid}>
          {subjects.map((subject) => (
            <Pressable key={subject.title} accessibilityRole="button" accessibilityLabel={t("exploreSubject", { subject: subject.title, detail: subject.detail })} onPress={() => router.push("/learn")} style={({ pressed }) => [styles.subjectCard, { borderTopColor: subject.color }, pressed && styles.cardPressed]}>
              <View style={[styles.subjectIcon, { backgroundColor: `${subject.color}18` }]}><IconSymbol name={subject.icon} size={22} color={subject.color} /></View>
              <Text className="mt-3 text-base font-bold text-foreground">{subject.title}</Text>
              <Text className="mt-1 text-xs text-muted">{subject.detail}</Text>
              <Text className="mt-4 text-xs font-semibold" style={{ color: subject.color }}>{subject.progress}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.encouragement}><Text style={styles.quote}>{`“${t("tutorQuote")}”`}</Text><Text style={styles.quoteSource}>— {t("tutorName")}</Text></View>
        <Modal visible={onboardingVisible} transparent animationType="slide" onRequestClose={() => setOnboardingVisible(false)}><View style={styles.modalBackdrop}><View style={styles.onboardingCard}><Text style={styles.onboardingTitle}>{t("onboardingTitle")}</Text><Text style={styles.onboardingText}>{t("onboardingText")}</Text><Text style={styles.onboardingLabel}>{t("profileName")}</Text><TextInput value={learnerProfile.name} onChangeText={(name) => setLearnerProfile((current) => ({ ...current, name }))} accessibilityLabel={t("profileName")} style={styles.onboardingInput} placeholder={t("profileName")} placeholderTextColor="#A9A09A" /><Text style={styles.onboardingLabel}>{t("ageBand")}</Text><View style={styles.onboardingChoices}>{(["5-7", "8-10", "11-13"] as AgeBand[]).map((ageBand) => <Pressable key={ageBand} onPress={() => setLearnerProfile((current) => ({ ...current, ageBand }))} accessibilityRole="button" accessibilityState={{ selected: learnerProfile.ageBand === ageBand }} style={[styles.onboardingChoice, learnerProfile.ageBand === ageBand && styles.onboardingChoiceSelected]}><Text style={styles.onboardingChoiceText}>{ageBand}</Text></Pressable>)}</View><Text style={styles.onboardingLabel}>{t("learningGoal")}</Text><View style={styles.onboardingChoices}>{(["reading", "writing", "math", "confidence"] as LearningGoal[]).map((goal) => <Pressable key={goal} onPress={() => setLearnerProfile((current) => ({ ...current, goal }))} accessibilityRole="button" accessibilityState={{ selected: learnerProfile.goal === goal }} style={[styles.onboardingChoice, learnerProfile.goal === goal && styles.onboardingChoiceSelected]}><Text style={styles.onboardingChoiceText}>{getGoalLabel(goal, language)}</Text></Pressable>)}</View><Pressable onPress={() => { const next = { ...learnerProfile, onboardingComplete: false, onboardingSkipped: true }; setLearnerProfile(next); saveLearnerProfile(next).catch(() => undefined); setOnboardingVisible(false); }} accessibilityRole="button" accessibilityLabel={t("skipForNow")} style={styles.onboardingSkip}><Text style={styles.onboardingSkipText}>{t("skipForNow")}</Text></Pressable><Pressable onPress={() => { const next = { ...learnerProfile, onboardingComplete: true, onboardingSkipped: false }; setLearnerProfile(next); saveLearnerProfile(next).catch(() => undefined); setOnboardingVisible(false); }} accessibilityRole="button" accessibilityLabel={t("saveProfile")} style={styles.onboardingSave}><Text style={styles.onboardingSaveText}>{t("saveProfile")}</Text></Pressable></View></View></Modal><Modal visible={walkthroughVisible} transparent animationType="fade" onRequestClose={() => { setWalkthroughVisible(false); completeWalkthrough().catch(() => undefined); }}><View style={styles.modalBackdrop}><View style={styles.walkthroughCard}><View style={styles.walkthroughIcon}><IconSymbol name="lightbulb.fill" size={24} color="#8B6B00" /></View><Text style={styles.walkthroughTitle}>{t("walkthroughTitle")}</Text><Text style={styles.walkthroughStep} accessibilityRole="text" accessibilityLabel={`${t("walkthroughProgressA11y", { current: walkthroughStep + 1, total: walkthroughSteps.length })}. ${walkthroughSteps[walkthroughStep]}`}>{walkthroughSteps[walkthroughStep]}</Text><View style={styles.walkthroughDots} accessibilityRole="progressbar" accessibilityValue={{ min: 1, max: walkthroughSteps.length, now: walkthroughStep + 1 }} accessibilityLabel={t("walkthroughProgressA11y", { current: walkthroughStep + 1, total: walkthroughSteps.length })}>{walkthroughSteps.map((_, index) => <View key={index} style={[styles.walkthroughDot, index === walkthroughStep && styles.walkthroughDotActive]} />)}</View><Pressable onPress={() => { if (walkthroughStep < walkthroughSteps.length - 1) setWalkthroughStep((step) => step + 1); else { setWalkthroughVisible(false); completeWalkthrough().catch(() => undefined); } }} accessibilityRole="button" accessibilityLabel={walkthroughStep < walkthroughSteps.length - 1 ? t("walkthroughNext") : t("walkthroughDone")} style={styles.onboardingSave}><Text style={styles.onboardingSaveText}>{walkthroughStep < walkthroughSteps.length - 1 ? t("walkthroughNext") : t("walkthroughDone")}</Text></Pressable></View></View></Modal>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: 32, gap: 22 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: "#DCE7FF", alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#246BFD", fontSize: 18, fontWeight: "800" },
  pressed: { opacity: 0.7 },
  cueCard: { flexDirection: "row", alignItems: "flex-start", padding: 14, borderRadius: 18, backgroundColor: "#E8F0FF", gap: 10 }, cueIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#F4C95D", alignItems: "center", justifyContent: "center" }, cueCopy: { flex: 1 }, cueTitle: { color: "#1F2933", fontWeight: "900", fontSize: 13 }, cueText: { color: "#50627A", marginTop: 3, fontSize: 12, lineHeight: 17 }, cueClose: { padding: 3 }, cueCloseText: { color: "#50627A", fontSize: 22, lineHeight: 22 },   setupReminder: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "#E8F0FF", borderRadius: 18, padding: 14 }, setupReminderIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" }, setupReminderCopy: { flex: 1 }, setupReminderTitle: { color: "#1F2933", fontSize: 13, fontWeight: "900" }, setupReminderText: { color: "#50627A", fontSize: 11, marginTop: 3 }, setupReminderArrow: { color: "#246BFD", fontSize: 24 },
  rewardCard: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 18, backgroundColor: "#E5F6EB" }, rewardIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#F4C95D", alignItems: "center", justifyContent: "center" }, rewardCopy: { flex: 1, marginLeft: 11 }, rewardTitle: { color: "#1F2933", fontWeight: "900", fontSize: 14 }, rewardSubtitle: { color: "#56705D", marginTop: 3, fontSize: 12 }, rewardPoints: { color: "#2E7D4F", fontSize: 15, fontWeight: "900" }, streakCard: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 18, backgroundColor: "#FFF3C7" },
  streakIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#F4C95D", alignItems: "center", justifyContent: "center" },
  streakCopy: { flex: 1, marginLeft: 12 },
  streakTitle: { color: "#1F2933", fontWeight: "800", fontSize: 15 },
  streakSubtitle: { color: "#6B6250", marginTop: 3, fontSize: 12 },
  streakCount: { color: "#1F2933", fontSize: 24, fontWeight: "900", marginRight: 4 },
  sectionHeader: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between" },
  progressPill: { paddingHorizontal: 10, paddingVertical: 6, backgroundColor: "#E8F0FF", borderRadius: 20 },
  progressPillText: { color: "#246BFD", fontSize: 12, fontWeight: "800" },
  heroCard: { backgroundColor: "#246BFD", borderRadius: 24, padding: 20, minHeight: 190 },
  cardPressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  heroTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  heroEyebrow: { color: "#DCE7FF", letterSpacing: 1.2, fontSize: 11, fontWeight: "800" },
  heroTitle: { color: "#FFFFFF", fontSize: 28, fontWeight: "900", marginTop: 26 },
  recommendationReason: { color: "#DCE7FF", fontSize: 12, fontWeight: "700", marginTop: 14 }, heroBody: { color: "#EAF0FF", fontSize: 14, lineHeight: 20, marginTop: 7, maxWidth: 260 },
  heroFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 22 },
  duration: { flexDirection: "row", alignItems: "center", gap: 6 },
  durationText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  startText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
  subjectGrid: { flexDirection: "row", gap: 10 },
  subjectCard: { flex: 1, minHeight: 150, backgroundColor: "#FFFFFF", borderRadius: 18, borderWidth: 1, borderColor: "#F0E8DC", borderTopWidth: 4, padding: 13 },
  subjectIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  encouragement: { padding: 18, backgroundColor: "#F3EEE7", borderRadius: 18 },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(31,41,51,0.38)" }, walkthroughCard: { backgroundColor: "#FFFDF8", borderRadius: 26, padding: 24, gap: 14, alignItems: "center", marginHorizontal: 22 }, walkthroughIcon: { width: 54, height: 54, borderRadius: 18, backgroundColor: "#F4C95D", alignItems: "center", justifyContent: "center" }, walkthroughTitle: { color: "#1F2933", fontSize: 23, fontWeight: "900" }, walkthroughStep: { color: "#6B6250", fontSize: 15, lineHeight: 22, textAlign: "center" }, walkthroughDots: { flexDirection: "row", gap: 6, marginTop: 4 }, walkthroughDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#D9D0C5" }, walkthroughDotActive: { width: 20, backgroundColor: "#246BFD" }, onboardingCard: { backgroundColor: "#FFFDF8", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, gap: 10 }, onboardingTitle: { color: "#1F2933", fontSize: 22, fontWeight: "900" }, onboardingText: { color: "#6B6250", fontSize: 13, lineHeight: 19 }, onboardingLabel: { color: "#6F665C", fontSize: 12, fontWeight: "800", marginTop: 4 }, onboardingInput: { minHeight: 46, borderWidth: 1, borderColor: "#E8DED0", borderRadius: 12, paddingHorizontal: 12, color: "#1F2933", fontSize: 15 }, onboardingChoices: { flexDirection: "row", flexWrap: "wrap", gap: 7 }, onboardingChoice: { borderRadius: 11, paddingHorizontal: 10, paddingVertical: 8, backgroundColor: "#F3EEE7" }, onboardingChoiceSelected: { backgroundColor: "#E8F0FF" }, onboardingChoiceText: { color: "#50627A", fontSize: 11, fontWeight: "800" }, onboardingSave: { backgroundColor: "#246BFD", borderRadius: 14, alignItems: "center", paddingVertical: 13, marginTop: 6 }, onboardingSaveText: { color: "#FFFFFF", fontWeight: "900" }, onboardingSkip: { alignItems: "center", paddingVertical: 8 }, onboardingSkipText: { color: "#6F665C", fontWeight: "800", fontSize: 12 },
  quote: { color: "#1F2933", fontSize: 15, fontWeight: "700", lineHeight: 22 },
  quoteSource: { color: "#8B8175", marginTop: 7, fontSize: 12 },
});
