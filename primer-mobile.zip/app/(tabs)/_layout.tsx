import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/lib/language-provider";

export default function TabLayout() {
  const colors = useColors();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: "#A39A90", tabBarButton: HapticTab, tabBarStyle: { paddingTop: 8, paddingBottom: bottomPadding, height: 56 + bottomPadding, backgroundColor: "#FFFDF9", borderTopColor: "#F0E8DC", borderTopWidth: 0.5 } }}><Tabs.Screen name="index" options={{ title: t("today"), tabBarIcon: ({ color }) => <IconSymbol size={24} name="house.fill" color={color} /> }} /><Tabs.Screen name="learn" options={{ title: t("learn"), tabBarIcon: ({ color }) => <IconSymbol size={24} name="book.fill" color={color} /> }} /><Tabs.Screen name="progress" options={{ title: t("progress"), tabBarIcon: ({ color }) => <IconSymbol size={24} name="chart.bar.fill" color={color} /> }} /><Tabs.Screen name="profile" options={{ title: t("profile"), tabBarIcon: ({ color }) => <IconSymbol size={24} name="person.crop.circle" color={color} /> }} /></Tabs>;
}
