# The Primer Mobile Interface Design

## Product Direction

The Primer is a calm, encouraging learning companion for children. The MVP prioritizes a clear daily learning path, short practice sessions, visible progress, and an approachable tutor presence. The experience is designed for portrait mobile screens and one-handed use, following mainstream iOS conventions: large readable type, generous touch targets, clear hierarchy, friendly feedback, and minimal cognitive load.

## Screen List

| Screen | Primary content and functionality |
|---|---|
| Home / Today | Greeting, daily streak, progress summary, recommended next lesson, subject cards for Reading, Writing, and Math, and a prominent Continue button. |
| Learn / Subject list | Filterable list of available learning paths grouped by subject, with completion state and recommended difficulty. |
| Lesson Detail | Lesson objective, estimated duration, prerequisite context, sample activity, and Start lesson action. |
| Tutor Session | Conversational tutoring interface with tutor prompt, learner response controls, hint action, progress indicator, and completion feedback. |
| Progress | Weekly learning activity, subject mastery cards, recent achievements, and a simple reflection on strengths and next steps. |
| Profile / Settings | Learner name, avatar treatment, language preference, accessibility preferences, sound/haptics toggles, and parent area entry point. |

## Key User Flows

### Continue today's learning

1. The learner opens Home and sees the recommended next activity.
2. The learner taps Continue.
3. Lesson Detail explains the goal and duration.
4. The learner taps Start lesson.
5. Tutor Session presents one activity at a time with hints and positive feedback.
6. Completing the activity updates the session progress and returns the learner to Home with a completion state.

### Explore a subject

1. The learner opens Learn from the tab bar.
2. The learner selects Reading, Writing, or Math.
3. The learner chooses a lesson card.
4. The learner reviews the objective and starts the lesson.

### Review progress

1. The learner opens Progress.
2. The learner sees recent activity and subject-level progress.
3. The learner taps a subject card to understand the current focus and recommended next practice.

## Interaction and Accessibility

All primary actions use large rounded controls with clear pressed feedback and optional light haptics. Lesson content uses short paragraphs, high-contrast text, and explicit labels rather than relying on color alone. Progress indicators include text labels. The MVP keeps navigation shallow and supports dynamic content sizing through flexible layouts.

## Color Choices

The brand uses a warm paper background (`#FFF9F0`) with deep ink (`#1F2933`) for readability. Primary actions use Primer blue (`#246BFD`), while reading uses coral (`#F97360`), writing uses violet (`#8B5CF6`), and math uses teal (`#0EA5A4`). Success feedback uses leaf green (`#2E9D65`), and gentle yellow (`#F4C95D`) highlights streaks and encouragement. Surfaces use white with subtle warm borders (`#F0E8DC`).

## MVP Data Strategy

The first pass uses local deterministic lesson and progress data so the core learner flow is demonstrable offline. The architecture should keep data models separate from screen components, allowing future replacement with the planned server-side content, progress, and AI tutor services without redesigning the navigation shell.
